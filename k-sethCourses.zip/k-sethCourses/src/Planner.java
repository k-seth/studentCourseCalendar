/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

import exceptions.CourseAlreadyExistsException;
import exceptions.CourseNotFoundException;
import exceptions.NullObjectException;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import univ.Administrator;
import univ.BCG;
import univ.CS;
import univ.Course;
import univ.CourseCatalog;
import univ.Credits;
import univ.DBCourseCatalog;
import univ.DBDetails;
import univ.DBStudent;
import univ.Degree;
import univ.DegreeRequiredCourses;
import univ.MyConnection;
import univ.SEng;
import user.Attempt;
import user.Semester;
import user.Student;

/**
 * A GUI class that is the primary workhorse for the assignment.
 *
 */
public class Planner extends javax.swing.JFrame {
    /**
     * An inner class to help with tracking table info deletion.
     * Implements KeyListener to allow a KeyEvent to be tracked and used.
     */
    private class deleteFromTranscript implements KeyListener {
        /**
         * Removes a course from the transcript, and clears the entry from the table.
         *
         * @param e
         */
        public void delete(KeyEvent e) {
           JTable table = (JTable) e.getComponent();
           DefaultTableModel model = (DefaultTableModel) table.getModel();

            /* This if checks to make sure the user is pressing shift, and as well as the delete key */
            if(e.getKeyCode() == KeyEvent.VK_DELETE && (e.getModifiers() & ActionEvent.SHIFT_MASK) == ActionEvent.SHIFT_MASK) {
                try {
                    currentStudent.removeAttempt(model.getValueAt(table.getSelectedRow(), 1).toString(), model.getValueAt(table.getSelectedRow(), 0).toString());

                    model.addRow(new String[3]);
                    model.removeRow(table.getSelectedRow());

                    populateTranscriptTables();
                    populateDegreeTables();
                    setTables();
                } catch(ArrayIndexOutOfBoundsException ex) {
                    // Do nothing
                }
            }
        }

        /**
         * Updates a the table and any tables affect by side affect.
         *
         * @param e
         */
        public void update(KeyEvent e) {
            JTable table = (JTable) e.getComponent();
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            String input;

            try {
                input = model.getValueAt(table.getSelectedRow(), 2).toString().toUpperCase();
                /* Check to confirm valid input first */
                if(input.equals("P") || input.equals("F") || input.equals("INC") || input.equals("MNR")) {
                    for(Attempt attempt : currentStudent.getTranscript().values()) {
                        if(attempt.getCourseAttempted().getCourseCode().equals(model.getValueAt(table.getSelectedRow(), 1).toString()) && attempt.getSemesterTaken().equals(model.getValueAt(table.getSelectedRow(), 0).toString())) {
                            attempt.setAttemptGrade(input);
                            break;
                        }
                    }
                } else if((Double.parseDouble(input) >= 0 && Double.parseDouble(input) <= 100)) {
                    for(Attempt attempt : currentStudent.getTranscript().values()) {
                        if(attempt.getCourseAttempted().getCourseCode().equals(model.getValueAt(table.getSelectedRow(), 1).toString()) && attempt.getSemesterTaken().equals(model.getValueAt(table.getSelectedRow(), 0).toString())) {
                            attempt.setAttemptGrade(input);
                            break;
                        }
                    }
                } else {
                    model.setValueAt(null, table.getSelectedRow(), 2);
                }
            } catch(ArrayIndexOutOfBoundsException | NumberFormatException ex) {
                // Do nothing
            }
            populateTranscriptTables();
            populateDegreeTables();
            setTables();
        }

        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override
        public void keyPressed(KeyEvent e) {
            if(e.getKeyCode() == KeyEvent.VK_DELETE && (e.getModifiers() & ActionEvent.SHIFT_MASK) == ActionEvent.SHIFT_MASK) {
                delete(e);
            } else if(e.getKeyCode() == KeyEvent.VK_ENTER) {
                update(e);
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {
        }
    }

    /**
     * An inner class to help with tracking table info deletion.
     * Implements KeyListener to allow a KeyEvent to be tracked and used.
     */
    private class deleteFromPOS implements KeyListener {
        /**
         * Removes a course from the plan of study, and clears the entry from the table.
         *
         * @param e
         */
        protected void delete(KeyEvent e) {
            JTable table = (JTable) e.getComponent();
            DefaultTableModel model = (DefaultTableModel) table.getModel();

            /* This if checks to make sure the user pressed shift, and as well as the delete key */
            if(e.getKeyCode() == KeyEvent.VK_DELETE && (e.getModifiers() & ActionEvent.SHIFT_MASK) == ActionEvent.SHIFT_MASK) {
                try {
                    currentStudent.removePlanned(model.getValueAt(table.getSelectedRow(), 1).toString(), model.getValueAt(table.getSelectedRow(), 0).toString());
                } catch(ArrayIndexOutOfBoundsException ex) {
                    // Do nothing
                }
                model.addRow(new String[2]);
                model.removeRow(table.getSelectedRow());

                populatePOSTables();
                populateDegreeTables();
                setTables();
            }
        }

        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override
        public void keyPressed(KeyEvent e) {
            if(e.getKeyCode() == KeyEvent.VK_DELETE && (e.getModifiers() & ActionEvent.SHIFT_MASK) == ActionEvent.SHIFT_MASK) {
                delete(e);
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {
        }
    }

    private static final long serialVersionUID = 1L;
    private static final String HINT_TEXT = "Enter Course Code";
    private static final String DEFAULT_TEXT = "Course:\n\n"+ "Offered:\n\n" + "Credits:";

    private final List<JTable> plannedTables = new ArrayList<>();
    private final List<JTable> transcriptTables = new ArrayList<>();
    private final List<JTable> degreeTables = new ArrayList<>();
    private final CourseCatalog catalog;
    private final MyConnection dbConnect;

    private final Degree CS;
    private final Degree SEng;
    private final Degree BCG;

    private Student currentStudent;
    private Course searchedCourse;


    /**
     * Creates new form planner
     */
    public Planner() {
        catalog = new DBCourseCatalog();
//        catalog = new CourseCatalog(TestClass.initializeCatalog("2430 Final Project Course List - Course List.csv")); -- Testing w/o database
        currentStudent = null;
        searchedCourse = null;
        dbConnect = new MyConnection(DBDetails.username, DBDetails.password);
//        dbConnect.deleteAllSavedStudent(); -- Testing

        CS = DegreeRequiredCourses.setCSRequiredCourses(catalog);
        SEng = DegreeRequiredCourses.setSENGRequiredCourses(catalog);
        BCG = DegreeRequiredCourses.setBCGRequiredCourses(catalog);

        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jDialog2 = new javax.swing.JDialog();
        courseSearchAndSelectPanel = new javax.swing.JPanel();
        courseSelectionPane = new javax.swing.JPanel();
        addToPlannedButton = new javax.swing.JButton();
        addToTranscriptButton = new javax.swing.JButton();
        courseSearchLabel = new javax.swing.JLabel();
        courseSearchTextField = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        courseInfoTextArea = new javax.swing.JTextArea();
        jScrollPane1 = new javax.swing.JScrollPane();
        coursePrerequisiteTable = new javax.swing.JTable();
        coursePrerequisiteLabel = new javax.swing.JLabel();
        clearAreaButton = new javax.swing.JButton();
        addToLabel = new javax.swing.JLabel();
        workAreaPanel = new javax.swing.JPanel();
        studentTabbedPane = new javax.swing.JTabbedPane();
        planOfStudyPanel = new javax.swing.JPanel();
        plannedCreditsLabel = new javax.swing.JLabel();
        plannedCreditsButton = new javax.swing.JButton();
        planOfStudyTabbedPane = new javax.swing.JTabbedPane();
        posY1Panel = new javax.swing.JPanel();
        jScrollPane22 = new javax.swing.JScrollPane();
        posY1S1Table = new javax.swing.JTable();
        jScrollPane23 = new javax.swing.JScrollPane();
        posY1S2Table = new javax.swing.JTable();
        posY2Panel = new javax.swing.JPanel();
        jScrollPane20 = new javax.swing.JScrollPane();
        posY2S1Table = new javax.swing.JTable();
        jScrollPane21 = new javax.swing.JScrollPane();
        posY2S2Table = new javax.swing.JTable();
        posY3Panel = new javax.swing.JPanel();
        jScrollPane18 = new javax.swing.JScrollPane();
        posY3S1Table = new javax.swing.JTable();
        jScrollPane19 = new javax.swing.JScrollPane();
        posY3S2Table = new javax.swing.JTable();
        posY4Panel = new javax.swing.JPanel();
        jScrollPane16 = new javax.swing.JScrollPane();
        posY4S1Table = new javax.swing.JTable();
        jScrollPane17 = new javax.swing.JScrollPane();
        posY4S2Table = new javax.swing.JTable();
        posY5Panel = new javax.swing.JPanel();
        jScrollPane14 = new javax.swing.JScrollPane();
        posY5S1Table = new javax.swing.JTable();
        jScrollPane15 = new javax.swing.JScrollPane();
        posY5S2Table = new javax.swing.JTable();
        missingCoursesPanel = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        missingCoursesTable = new javax.swing.JTable();
        planOfStudyTabLabel = new javax.swing.JLabel();
        numCreditsRemainingLabel = new javax.swing.JLabel();
        refreshNumCreditsButton = new javax.swing.JButton();
        transcriptPanel = new javax.swing.JPanel();
        passedCreditsLabel = new javax.swing.JLabel();
        passedCreditsButton = new javax.swing.JButton();
        transcriptTabbedPane = new javax.swing.JTabbedPane();
        transcriptY1Panel = new javax.swing.JPanel();
        jScrollPane52 = new javax.swing.JScrollPane();
        transcriptY1S1Table = new javax.swing.JTable();
        jScrollPane53 = new javax.swing.JScrollPane();
        transcriptY1S2Table = new javax.swing.JTable();
        transcriptY2Panel = new javax.swing.JPanel();
        jScrollPane50 = new javax.swing.JScrollPane();
        transcriptY2S1Table = new javax.swing.JTable();
        jScrollPane51 = new javax.swing.JScrollPane();
        transcriptY2S2Table = new javax.swing.JTable();
        transcriptY3Panel = new javax.swing.JPanel();
        jScrollPane48 = new javax.swing.JScrollPane();
        transcriptY3S1Table = new javax.swing.JTable();
        jScrollPane49 = new javax.swing.JScrollPane();
        transcriptY3S2Table = new javax.swing.JTable();
        transcriptY4Panel = new javax.swing.JPanel();
        jScrollPane46 = new javax.swing.JScrollPane();
        transcriptY4S1Table = new javax.swing.JTable();
        jScrollPane47 = new javax.swing.JScrollPane();
        transcriptY4S2Table = new javax.swing.JTable();
        transcriptY5Panel = new javax.swing.JPanel();
        jScrollPane44 = new javax.swing.JScrollPane();
        transcriptY5S1Table = new javax.swing.JTable();
        jScrollPane45 = new javax.swing.JScrollPane();
        transcriptY5S2Table = new javax.swing.JTable();
        transcriptTabLabel = new javax.swing.JLabel();
        transcriptEditLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        degreePanel = new javax.swing.JPanel();
        gpaCalculatorComboBox = new javax.swing.JComboBox<>();
        gpaPrintLabel = new javax.swing.JLabel();
        degreeTabbedPane = new javax.swing.JTabbedPane();
        jPanel12 = new javax.swing.JPanel();
        jScrollPane42 = new javax.swing.JScrollPane();
        degreeY1S1Table = new javax.swing.JTable();
        jScrollPane43 = new javax.swing.JScrollPane();
        degreeY1S2Table = new javax.swing.JTable();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane40 = new javax.swing.JScrollPane();
        degreeY2S1Table = new javax.swing.JTable();
        jScrollPane41 = new javax.swing.JScrollPane();
        degreeY2S2Table = new javax.swing.JTable();
        jPanel14 = new javax.swing.JPanel();
        jScrollPane38 = new javax.swing.JScrollPane();
        degreeY3S1Table = new javax.swing.JTable();
        jScrollPane39 = new javax.swing.JScrollPane();
        degreeY3S2Table = new javax.swing.JTable();
        jPanel15 = new javax.swing.JPanel();
        jScrollPane36 = new javax.swing.JScrollPane();
        degreeY4S1Table = new javax.swing.JTable();
        jScrollPane37 = new javax.swing.JScrollPane();
        degreeY4S2Table = new javax.swing.JTable();
        jPanel16 = new javax.swing.JPanel();
        jScrollPane34 = new javax.swing.JScrollPane();
        degreeY5S1Table = new javax.swing.JTable();
        jScrollPane35 = new javax.swing.JScrollPane();
        degreeY5S2Table = new javax.swing.JTable();
        notListedPanel = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        notListedTable = new javax.swing.JTable();
        incompletePanel = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        incompleteTable = new javax.swing.JTable();
        degreeTabLabel = new javax.swing.JLabel();
        gpaDegreeRefreshLabel = new javax.swing.JButton();
        checkRequirementsLabel = new javax.swing.JLabel();
        requirementsMetLabel = new javax.swing.JButton();
        loginPromptLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        menuBar = new javax.swing.JMenuBar();
        userMenu = new javax.swing.JMenu();
        userSettingsMenu = new javax.swing.JMenu();
        nameSettingMenuItem = new javax.swing.JMenuItem();
        degreeSettingsMenuItem = new javax.swing.JMenuItem();
        switchUserMenuItem = new javax.swing.JMenuItem();
        createUserMenuItem = new javax.swing.JMenuItem();
        userActionSeperator = new javax.swing.JPopupMenu.Separator();
        adminLoginMenuItem = new javax.swing.JMenuItem();
        exitSeparator = new javax.swing.JPopupMenu.Separator();
        exitMenuItem = new javax.swing.JMenuItem();
        fileMenu = new javax.swing.JMenu();
        saveMenuItem = new javax.swing.JMenuItem();
        aboutMenu = new javax.swing.JMenu();
        aboutProgramMenuItem = new javax.swing.JMenuItem();
        helpMenuItem = new javax.swing.JMenuItem();

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout jDialog2Layout = new javax.swing.GroupLayout(jDialog2.getContentPane());
        jDialog2.getContentPane().setLayout(jDialog2Layout);
        jDialog2Layout.setHorizontalGroup(
            jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog2Layout.setVerticalGroup(
            jDialog2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("WebAdvisor");
        setBackground(new java.awt.Color(0, 0, 0));
        setResizable(false);
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        courseSearchAndSelectPanel.setBackground(new java.awt.Color(204, 0, 0));
        courseSearchAndSelectPanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 51), new java.awt.Color(255, 153, 51)));

        courseSelectionPane.setBackground(new java.awt.Color(204, 0, 0));

        addToPlannedButton.setText("Plan of Study");
        addToPlannedButton.setToolTipText("Adds the searched course to the plan of study");
        addToPlannedButton.setAlignmentX(CENTER_ALIGNMENT);
        addToPlannedButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addToPlannedButtonActionPerformed(evt);
            }
        });
        courseSelectionPane.add(addToPlannedButton);

        addToTranscriptButton.setText(" Transcript ");
        addToTranscriptButton.setToolTipText("Adds the searched course to the transcript");
        addToTranscriptButton.setAlignmentX(CENTER_ALIGNMENT);
        addToTranscriptButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addToTranscriptButtonActionPerformed(evt);
            }
        });
        courseSelectionPane.add(addToTranscriptButton);

        courseSelectionPane.setVisible(false);

        courseSearchLabel.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        courseSearchLabel.setForeground(new java.awt.Color(255, 255, 255));
        courseSearchLabel.setText("Search: ");

        courseSearchTextField.setText(HINT_TEXT);
        courseSearchTextField.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 51), new java.awt.Color(255, 153, 51)));
        courseSearchTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                courseSearchTextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                courseSearchTextFieldFocusLost(evt);
            }
        });
        courseSearchTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                courseSearchTextFieldKeyPressed(evt);
            }
        });

        jScrollPane4.setBackground(new java.awt.Color(255, 102, 0));
        jScrollPane4.setBorder(null);

        courseInfoTextArea.setEditable(false);
        courseInfoTextArea.setColumns(20);
        courseInfoTextArea.setRows(5);
        courseInfoTextArea.setText(DEFAULT_TEXT);
        courseInfoTextArea.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 51), new java.awt.Color(255, 153, 51)));
        jScrollPane4.setViewportView(courseInfoTextArea);

        coursePrerequisiteTable.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 51), new java.awt.Color(255, 153, 51)));
        coursePrerequisiteTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Course Code", "Semester Offered"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        coursePrerequisiteTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        coursePrerequisiteTable.getTableHeader().setResizingAllowed(false);
        coursePrerequisiteTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(coursePrerequisiteTable);

        coursePrerequisiteLabel.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        coursePrerequisiteLabel.setForeground(new java.awt.Color(255, 255, 255));
        coursePrerequisiteLabel.setText("Course Prerequisites");

        clearAreaButton.setText("Clear");
        clearAreaButton.setToolTipText("Clears search bar and all displayed course information");
        clearAreaButton.setAlignmentX(CENTER_ALIGNMENT);
        clearAreaButton.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        clearAreaButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearAreaButtonActionPerformed(evt);
            }
        });

        addToLabel.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        addToLabel.setVisible(false);
        addToLabel.setForeground(new java.awt.Color(255, 255, 255));
        addToLabel.setText("Add To:");

        javax.swing.GroupLayout courseSearchAndSelectPanelLayout = new javax.swing.GroupLayout(courseSearchAndSelectPanel);
        courseSearchAndSelectPanel.setLayout(courseSearchAndSelectPanelLayout);
        courseSearchAndSelectPanelLayout.setHorizontalGroup(
            courseSearchAndSelectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(courseSearchAndSelectPanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(courseSearchAndSelectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, courseSearchAndSelectPanelLayout.createSequentialGroup()
                        .addComponent(addToLabel)
                        .addGap(119, 119, 119))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, courseSearchAndSelectPanelLayout.createSequentialGroup()
                        .addGroup(courseSearchAndSelectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(courseSearchAndSelectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(courseSearchAndSelectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(courseSearchAndSelectPanelLayout.createSequentialGroup()
                                        .addGap(15, 15, 15)
                                        .addGroup(courseSearchAndSelectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(courseSearchAndSelectPanelLayout.createSequentialGroup()
                                                .addComponent(courseSearchLabel)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(courseSearchTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(clearAreaButton))
                                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(courseSearchAndSelectPanelLayout.createSequentialGroup()
                                        .addGap(82, 82, 82)
                                        .addComponent(coursePrerequisiteLabel)))
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 252, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(courseSearchAndSelectPanelLayout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addComponent(courseSelectionPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(14, 14, 14))))
        );
        courseSearchAndSelectPanelLayout.setVerticalGroup(
            courseSearchAndSelectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, courseSearchAndSelectPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(courseSearchAndSelectPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(courseSearchTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clearAreaButton)
                    .addComponent(courseSearchLabel))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(4, 4, 4)
                .addComponent(addToLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(courseSelectionPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(coursePrerequisiteLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19))
        );

        workAreaPanel.setBackground(new java.awt.Color(153, 153, 153));

        planOfStudyPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        plannedCreditsLabel.setText("Total value of Planned Credits:");

        plannedCreditsButton.setText("Refresh");
        plannedCreditsButton.setToolTipText("Refreshes information for the above jLabel, in case new information has been added");
        plannedCreditsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                plannedCreditsButtonActionPerformed(evt);
            }
        });

        planOfStudyTabbedPane.setToolTipText("Shows all planned courses by semester");

        posY1S1Table.addKeyListener(new deleteFromPOS());
        posY1S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        posY1S1Table.setToolTipText("Use shift+del to remove the course at the selected row from the plan of study");
        posY1S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane22.setViewportView(posY1S1Table);
        if (posY1S1Table.getColumnModel().getColumnCount() > 0) {
            posY1S1Table.getColumnModel().getColumn(0).setResizable(false);
            posY1S1Table.getColumnModel().getColumn(1).setResizable(false);
        }

        posY1S2Table.addKeyListener(new deleteFromPOS());
        posY1S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        posY1S2Table.setToolTipText("Use shift+del to remove the course at the selected row from the plan of study");
        posY1S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane23.setViewportView(posY1S2Table);
        if (posY1S2Table.getColumnModel().getColumnCount() > 0) {
            posY1S2Table.getColumnModel().getColumn(0).setResizable(false);
            posY1S2Table.getColumnModel().getColumn(1).setResizable(false);
        }

        javax.swing.GroupLayout posY1PanelLayout = new javax.swing.GroupLayout(posY1Panel);
        posY1Panel.setLayout(posY1PanelLayout);
        posY1PanelLayout.setHorizontalGroup(
            posY1PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane22, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane23)
        );
        posY1PanelLayout.setVerticalGroup(
            posY1PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(posY1PanelLayout.createSequentialGroup()
                .addComponent(jScrollPane22, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane23, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        planOfStudyTabbedPane.addTab("Next Semesters", posY1Panel);

        posY2S1Table.addKeyListener(new deleteFromPOS());
        posY2S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        posY2S1Table.setToolTipText("Use shift+del to remove the course at the selected row from the plan of study");
        posY2S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane20.setViewportView(posY2S1Table);
        if (posY2S1Table.getColumnModel().getColumnCount() > 0) {
            posY2S1Table.getColumnModel().getColumn(0).setResizable(false);
            posY2S1Table.getColumnModel().getColumn(1).setResizable(false);
        }

        posY2S2Table.addKeyListener(new deleteFromPOS());
        posY2S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        posY2S2Table.setToolTipText("Use shift+del to remove the course at the selected row from the plan of study");
        posY2S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane21.setViewportView(posY2S2Table);
        if (posY2S2Table.getColumnModel().getColumnCount() > 0) {
            posY2S2Table.getColumnModel().getColumn(0).setResizable(false);
            posY2S2Table.getColumnModel().getColumn(1).setResizable(false);
        }

        javax.swing.GroupLayout posY2PanelLayout = new javax.swing.GroupLayout(posY2Panel);
        posY2Panel.setLayout(posY2PanelLayout);
        posY2PanelLayout.setHorizontalGroup(
            posY2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane20, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane21)
        );
        posY2PanelLayout.setVerticalGroup(
            posY2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(posY2PanelLayout.createSequentialGroup()
                .addComponent(jScrollPane20, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane21, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        planOfStudyTabbedPane.addTab("Future", posY2Panel);

        posY3S1Table.addKeyListener(new deleteFromPOS());
        posY3S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        posY3S1Table.setToolTipText("Use shift+del to remove the course at the selected row from the plan of study");
        posY3S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane18.setViewportView(posY3S1Table);
        if (posY3S1Table.getColumnModel().getColumnCount() > 0) {
            posY3S1Table.getColumnModel().getColumn(0).setResizable(false);
            posY3S1Table.getColumnModel().getColumn(1).setResizable(false);
        }

        posY3S2Table.addKeyListener(new deleteFromPOS());
        posY3S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        posY3S2Table.setToolTipText("Use shift+del to remove the course at the selected row from the plan of study");
        posY3S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane19.setViewportView(posY3S2Table);
        if (posY3S2Table.getColumnModel().getColumnCount() > 0) {
            posY3S2Table.getColumnModel().getColumn(0).setResizable(false);
            posY3S2Table.getColumnModel().getColumn(1).setResizable(false);
        }

        javax.swing.GroupLayout posY3PanelLayout = new javax.swing.GroupLayout(posY3Panel);
        posY3Panel.setLayout(posY3PanelLayout);
        posY3PanelLayout.setHorizontalGroup(
            posY3PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane18, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane19)
        );
        posY3PanelLayout.setVerticalGroup(
            posY3PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(posY3PanelLayout.createSequentialGroup()
                .addComponent(jScrollPane18, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane19, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        planOfStudyTabbedPane.addTab("Future", posY3Panel);

        posY4S1Table.addKeyListener(new deleteFromPOS());
        posY4S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        posY4S1Table.setToolTipText("Use shift+del to remove the course at the selected row from the plan of study");
        posY4S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane16.setViewportView(posY4S1Table);
        if (posY4S1Table.getColumnModel().getColumnCount() > 0) {
            posY4S1Table.getColumnModel().getColumn(0).setResizable(false);
            posY4S1Table.getColumnModel().getColumn(1).setResizable(false);
        }

        posY4S2Table.addKeyListener(new deleteFromPOS());
        posY4S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        posY4S2Table.setToolTipText("Use shift+del to remove the course at the selected row from the plan of study");
        posY4S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane17.setViewportView(posY4S2Table);
        if (posY4S2Table.getColumnModel().getColumnCount() > 0) {
            posY4S2Table.getColumnModel().getColumn(0).setResizable(false);
            posY4S2Table.getColumnModel().getColumn(1).setResizable(false);
        }

        javax.swing.GroupLayout posY4PanelLayout = new javax.swing.GroupLayout(posY4Panel);
        posY4Panel.setLayout(posY4PanelLayout);
        posY4PanelLayout.setHorizontalGroup(
            posY4PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane16, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane17)
        );
        posY4PanelLayout.setVerticalGroup(
            posY4PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(posY4PanelLayout.createSequentialGroup()
                .addComponent(jScrollPane16, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane17, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        planOfStudyTabbedPane.addTab("Future", posY4Panel);

        posY5S1Table.addKeyListener(new deleteFromPOS());
        posY5S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        posY5S1Table.setToolTipText("Use shift+del to remove the course at the selected row from the plan of study");
        posY5S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane14.setViewportView(posY5S1Table);
        if (posY5S1Table.getColumnModel().getColumnCount() > 0) {
            posY5S1Table.getColumnModel().getColumn(0).setResizable(false);
            posY5S1Table.getColumnModel().getColumn(1).setResizable(false);
        }

        posY5S2Table.addKeyListener(new deleteFromPOS());
        posY5S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        posY5S2Table.setToolTipText("Use shift+del to remove the course at the selected row from the plan of study");
        posY5S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane15.setViewportView(posY5S2Table);
        if (posY5S2Table.getColumnModel().getColumnCount() > 0) {
            posY5S2Table.getColumnModel().getColumn(0).setResizable(false);
            posY5S2Table.getColumnModel().getColumn(1).setResizable(false);
        }

        javax.swing.GroupLayout posY5PanelLayout = new javax.swing.GroupLayout(posY5Panel);
        posY5Panel.setLayout(posY5PanelLayout);
        posY5PanelLayout.setHorizontalGroup(
            posY5PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane14, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane15)
        );
        posY5PanelLayout.setVerticalGroup(
            posY5PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(posY5PanelLayout.createSequentialGroup()
                .addComponent(jScrollPane14, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane15, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        planOfStudyTabbedPane.addTab("Future", posY5Panel);

        missingCoursesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Course Code", "Semester Offered"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        missingCoursesTable.setToolTipText("All courses that must be added to take the courses currently in the plan of study");
        missingCoursesTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane2.setViewportView(missingCoursesTable);
        if (missingCoursesTable.getColumnModel().getColumnCount() > 0) {
            missingCoursesTable.getColumnModel().getColumn(1).setResizable(false);
        }

        javax.swing.GroupLayout missingCoursesPanelLayout = new javax.swing.GroupLayout(missingCoursesPanel);
        missingCoursesPanel.setLayout(missingCoursesPanelLayout);
        missingCoursesPanelLayout.setHorizontalGroup(
            missingCoursesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
        );
        missingCoursesPanelLayout.setVerticalGroup(
            missingCoursesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
        );

        planOfStudyTabbedPane.addTab("Courses To Add", missingCoursesPanel);

        planOfStudyTabLabel.setText("Placeholder");

        numCreditsRemainingLabel.setText("Number of credits to have at least 20:");

        refreshNumCreditsButton.setText("Refresh");
        refreshNumCreditsButton.setToolTipText("Refreshes information for the above jLabel, in case new information has been added");
        refreshNumCreditsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refreshNumCreditsButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout planOfStudyPanelLayout = new javax.swing.GroupLayout(planOfStudyPanel);
        planOfStudyPanel.setLayout(planOfStudyPanelLayout);
        planOfStudyPanelLayout.setHorizontalGroup(
            planOfStudyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(planOfStudyPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(planOfStudyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(plannedCreditsButton)
                    .addComponent(plannedCreditsLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(planOfStudyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(numCreditsRemainingLabel)
                    .addComponent(refreshNumCreditsButton))
                .addGap(96, 96, 96))
            .addGroup(planOfStudyPanelLayout.createSequentialGroup()
                .addGroup(planOfStudyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(planOfStudyPanelLayout.createSequentialGroup()
                        .addGap(241, 241, 241)
                        .addComponent(planOfStudyTabLabel))
                    .addGroup(planOfStudyPanelLayout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addComponent(planOfStudyTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 508, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(62, Short.MAX_VALUE))
        );
        planOfStudyPanelLayout.setVerticalGroup(
            planOfStudyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(planOfStudyPanelLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(planOfStudyTabLabel)
                .addGap(21, 21, 21)
                .addGroup(planOfStudyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(plannedCreditsLabel)
                    .addComponent(numCreditsRemainingLabel))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(planOfStudyPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(plannedCreditsButton)
                    .addComponent(refreshNumCreditsButton))
                .addGap(32, 32, 32)
                .addComponent(planOfStudyTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46))
        );

        studentTabbedPane.addTab("Plan of Study", planOfStudyPanel);

        transcriptPanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        passedCreditsLabel.setText("Total value of Passed Credits: ");

        passedCreditsButton.setText("Refresh");
        passedCreditsButton.setToolTipText("Refreshes information for the above jLabel, in case new information has been added");
        passedCreditsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passedCreditsButtonActionPerformed(evt);
            }
        });

        transcriptTabbedPane.setToolTipText("Shows all completed courses by semester");

        transcriptY1S1Table.addKeyListener(new deleteFromTranscript());
        transcriptY1S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        transcriptY1S1Table.setToolTipText("Use shift+del to remove the course at the selected row from the transcript");
        transcriptY1S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane52.setViewportView(transcriptY1S1Table);
        if (transcriptY1S1Table.getColumnModel().getColumnCount() > 0) {
            transcriptY1S1Table.getColumnModel().getColumn(0).setResizable(false);
            transcriptY1S1Table.getColumnModel().getColumn(1).setResizable(false);
            transcriptY1S1Table.getColumnModel().getColumn(2).setResizable(false);
        }

        transcriptY1S2Table.addKeyListener(new deleteFromTranscript());
        transcriptY1S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        transcriptY1S2Table.setToolTipText("Use shift+del to remove the course at the selected row from the transcript");
        transcriptY1S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane53.setViewportView(transcriptY1S2Table);
        if (transcriptY1S2Table.getColumnModel().getColumnCount() > 0) {
            transcriptY1S2Table.getColumnModel().getColumn(0).setResizable(false);
            transcriptY1S2Table.getColumnModel().getColumn(1).setResizable(false);
            transcriptY1S2Table.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout transcriptY1PanelLayout = new javax.swing.GroupLayout(transcriptY1Panel);
        transcriptY1Panel.setLayout(transcriptY1PanelLayout);
        transcriptY1PanelLayout.setHorizontalGroup(
            transcriptY1PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane52, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane53)
        );
        transcriptY1PanelLayout.setVerticalGroup(
            transcriptY1PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transcriptY1PanelLayout.createSequentialGroup()
                .addComponent(jScrollPane52, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane53, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        transcriptTabbedPane.addTab("Year 1", transcriptY1Panel);

        transcriptY2S1Table.addKeyListener(new deleteFromTranscript());
        transcriptY2S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        transcriptY2S1Table.setToolTipText("Use shift+del to remove the course at the selected row from the transcript");
        transcriptY2S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane50.setViewportView(transcriptY2S1Table);
        if (transcriptY2S1Table.getColumnModel().getColumnCount() > 0) {
            transcriptY2S1Table.getColumnModel().getColumn(0).setResizable(false);
            transcriptY2S1Table.getColumnModel().getColumn(1).setResizable(false);
            transcriptY2S1Table.getColumnModel().getColumn(2).setResizable(false);
        }

        transcriptY2S2Table.addKeyListener(new deleteFromTranscript());
        transcriptY2S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        transcriptY2S2Table.setToolTipText("Use shift+del to remove the course at the selected row from the transcript");
        transcriptY2S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane51.setViewportView(transcriptY2S2Table);
        if (transcriptY2S2Table.getColumnModel().getColumnCount() > 0) {
            transcriptY2S2Table.getColumnModel().getColumn(0).setResizable(false);
            transcriptY2S2Table.getColumnModel().getColumn(1).setResizable(false);
            transcriptY2S2Table.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout transcriptY2PanelLayout = new javax.swing.GroupLayout(transcriptY2Panel);
        transcriptY2Panel.setLayout(transcriptY2PanelLayout);
        transcriptY2PanelLayout.setHorizontalGroup(
            transcriptY2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane50, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane51)
        );
        transcriptY2PanelLayout.setVerticalGroup(
            transcriptY2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transcriptY2PanelLayout.createSequentialGroup()
                .addComponent(jScrollPane50, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane51, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        transcriptTabbedPane.addTab("Year 2", transcriptY2Panel);

        transcriptY3S1Table.addKeyListener(new deleteFromTranscript());
        transcriptY3S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        transcriptY3S1Table.setToolTipText("Use shift+del to remove the course at the selected row from the transcript");
        transcriptY3S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane48.setViewportView(transcriptY3S1Table);
        if (transcriptY3S1Table.getColumnModel().getColumnCount() > 0) {
            transcriptY3S1Table.getColumnModel().getColumn(0).setResizable(false);
            transcriptY3S1Table.getColumnModel().getColumn(1).setResizable(false);
            transcriptY3S1Table.getColumnModel().getColumn(2).setResizable(false);
        }

        transcriptY3S2Table.addKeyListener(new deleteFromTranscript());
        transcriptY3S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        transcriptY3S2Table.setToolTipText("Use shift+del to remove the course at the selected row from the transcript");
        transcriptY3S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane49.setViewportView(transcriptY3S2Table);
        if (transcriptY3S2Table.getColumnModel().getColumnCount() > 0) {
            transcriptY3S2Table.getColumnModel().getColumn(0).setResizable(false);
            transcriptY3S2Table.getColumnModel().getColumn(1).setResizable(false);
            transcriptY3S2Table.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout transcriptY3PanelLayout = new javax.swing.GroupLayout(transcriptY3Panel);
        transcriptY3Panel.setLayout(transcriptY3PanelLayout);
        transcriptY3PanelLayout.setHorizontalGroup(
            transcriptY3PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane48, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane49)
        );
        transcriptY3PanelLayout.setVerticalGroup(
            transcriptY3PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transcriptY3PanelLayout.createSequentialGroup()
                .addComponent(jScrollPane48, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane49, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        transcriptTabbedPane.addTab("Year 3", transcriptY3Panel);

        transcriptY4S1Table.addKeyListener(new deleteFromTranscript());
        transcriptY4S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        transcriptY4S1Table.setToolTipText("Use shift+del to remove the course at the selected row from the transcript");
        transcriptY4S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane46.setViewportView(transcriptY4S1Table);
        if (transcriptY4S1Table.getColumnModel().getColumnCount() > 0) {
            transcriptY4S1Table.getColumnModel().getColumn(0).setResizable(false);
            transcriptY4S1Table.getColumnModel().getColumn(1).setResizable(false);
            transcriptY4S1Table.getColumnModel().getColumn(2).setResizable(false);
        }

        transcriptY4S2Table.addKeyListener(new deleteFromTranscript());
        transcriptY4S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        transcriptY4S2Table.setToolTipText("Use shift+del to remove the course at the selected row from the transcript");
        transcriptY4S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane47.setViewportView(transcriptY4S2Table);
        if (transcriptY4S2Table.getColumnModel().getColumnCount() > 0) {
            transcriptY4S2Table.getColumnModel().getColumn(0).setResizable(false);
            transcriptY4S2Table.getColumnModel().getColumn(1).setResizable(false);
            transcriptY4S2Table.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout transcriptY4PanelLayout = new javax.swing.GroupLayout(transcriptY4Panel);
        transcriptY4Panel.setLayout(transcriptY4PanelLayout);
        transcriptY4PanelLayout.setHorizontalGroup(
            transcriptY4PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane46, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane47)
        );
        transcriptY4PanelLayout.setVerticalGroup(
            transcriptY4PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transcriptY4PanelLayout.createSequentialGroup()
                .addComponent(jScrollPane46, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane47, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        transcriptTabbedPane.addTab("Year 4", transcriptY4Panel);

        transcriptY5S1Table.addKeyListener(new deleteFromTranscript());
        transcriptY5S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        transcriptY5S1Table.setToolTipText("Use shift+del to remove the course at the selected row from the transcript");
        transcriptY5S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane44.setViewportView(transcriptY5S1Table);
        if (transcriptY5S1Table.getColumnModel().getColumnCount() > 0) {
            transcriptY5S1Table.getColumnModel().getColumn(0).setResizable(false);
            transcriptY5S1Table.getColumnModel().getColumn(1).setResizable(false);
            transcriptY5S1Table.getColumnModel().getColumn(2).setResizable(false);
        }

        transcriptY5S2Table.addKeyListener(new deleteFromTranscript());
        transcriptY5S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        transcriptY5S2Table.setToolTipText("Use shift+del to remove the course at the selected row from the transcript");
        transcriptY5S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane45.setViewportView(transcriptY5S2Table);
        if (transcriptY5S2Table.getColumnModel().getColumnCount() > 0) {
            transcriptY5S2Table.getColumnModel().getColumn(0).setResizable(false);
            transcriptY5S2Table.getColumnModel().getColumn(1).setResizable(false);
            transcriptY5S2Table.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout transcriptY5PanelLayout = new javax.swing.GroupLayout(transcriptY5Panel);
        transcriptY5Panel.setLayout(transcriptY5PanelLayout);
        transcriptY5PanelLayout.setHorizontalGroup(
            transcriptY5PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane44, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane45)
        );
        transcriptY5PanelLayout.setVerticalGroup(
            transcriptY5PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transcriptY5PanelLayout.createSequentialGroup()
                .addComponent(jScrollPane44, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane45, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        transcriptTabbedPane.addTab("Year 5", transcriptY5Panel);

        transcriptTabLabel.setText("Placeholder");

        transcriptEditLabel.setText("Grade is an editable cell");

        jLabel1.setText("To change your grade:");

        jLabel2.setText("1) Select the cell  2) Type new grade  3) Press enter (to exit cell editing)  4) Press enter to update grade");

        javax.swing.GroupLayout transcriptPanelLayout = new javax.swing.GroupLayout(transcriptPanel);
        transcriptPanel.setLayout(transcriptPanelLayout);
        transcriptPanelLayout.setHorizontalGroup(
            transcriptPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transcriptPanelLayout.createSequentialGroup()
                .addGroup(transcriptPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(transcriptPanelLayout.createSequentialGroup()
                        .addGap(241, 241, 241)
                        .addComponent(transcriptTabLabel))
                    .addGroup(transcriptPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(passedCreditsButton))
                    .addGroup(transcriptPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(passedCreditsLabel))
                    .addGroup(transcriptPanelLayout.createSequentialGroup()
                        .addGap(249, 249, 249)
                        .addGroup(transcriptPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addComponent(transcriptEditLabel)))
                    .addGroup(transcriptPanelLayout.createSequentialGroup()
                        .addGap(67, 67, 67)
                        .addGroup(transcriptPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(transcriptTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 508, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(62, Short.MAX_VALUE))
        );
        transcriptPanelLayout.setVerticalGroup(
            transcriptPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(transcriptPanelLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(transcriptTabLabel)
                .addGap(21, 21, 21)
                .addComponent(passedCreditsLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(passedCreditsButton)
                .addGap(32, 32, 32)
                .addComponent(transcriptTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(transcriptEditLabel)
                .addGap(3, 3, 3)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        studentTabbedPane.addTab("Transcript", transcriptPanel);

        degreePanel.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        gpaCalculatorComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] {"Calculate GPA", "Calculate CIS GPA", "Calculate last 10 GPA" }));
        gpaCalculatorComboBox.setToolTipText("Displays the GPA for the given option");
        gpaCalculatorComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gpaCalculatorComboBoxActionPerformed(evt);
            }
        });

        gpaPrintLabel.setText("GPA:");

        degreeTabbedPane.setToolTipText("Shows all courses, planned, and completed by semester");

        degreeY1S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        degreeY1S1Table.setToolTipText("This table can not be edited");
        degreeY1S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane42.setViewportView(degreeY1S1Table);
        if (degreeY1S1Table.getColumnModel().getColumnCount() > 0) {
            degreeY1S1Table.getColumnModel().getColumn(0).setResizable(false);
            degreeY1S1Table.getColumnModel().getColumn(1).setResizable(false);
            degreeY1S1Table.getColumnModel().getColumn(2).setResizable(false);
        }

        degreeY1S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        degreeY1S2Table.setToolTipText("This table can not be edited");
        degreeY1S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane43.setViewportView(degreeY1S2Table);
        if (degreeY1S2Table.getColumnModel().getColumnCount() > 0) {
            degreeY1S2Table.getColumnModel().getColumn(0).setResizable(false);
            degreeY1S2Table.getColumnModel().getColumn(1).setResizable(false);
            degreeY1S2Table.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane42, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane43)
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addComponent(jScrollPane42, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane43, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        degreeTabbedPane.addTab("Year 1", jPanel12);

        degreeY2S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        degreeY2S1Table.setToolTipText("This table can not be edited");
        degreeY2S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane40.setViewportView(degreeY2S1Table);
        if (degreeY2S1Table.getColumnModel().getColumnCount() > 0) {
            degreeY2S1Table.getColumnModel().getColumn(0).setResizable(false);
            degreeY2S1Table.getColumnModel().getColumn(1).setResizable(false);
            degreeY2S1Table.getColumnModel().getColumn(2).setResizable(false);
        }

        degreeY2S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        degreeY2S2Table.setToolTipText("This table can not be edited");
        degreeY2S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane41.setViewportView(degreeY2S2Table);
        if (degreeY2S2Table.getColumnModel().getColumnCount() > 0) {
            degreeY2S2Table.getColumnModel().getColumn(0).setResizable(false);
            degreeY2S2Table.getColumnModel().getColumn(1).setResizable(false);
            degreeY2S2Table.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane40, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane41)
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addComponent(jScrollPane40, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane41, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        degreeTabbedPane.addTab("Year 2", jPanel13);

        degreeY3S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        degreeY3S1Table.setToolTipText("This table can not be edited");
        degreeY3S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane38.setViewportView(degreeY3S1Table);
        if (degreeY3S1Table.getColumnModel().getColumnCount() > 0) {
            degreeY3S1Table.getColumnModel().getColumn(0).setResizable(false);
            degreeY3S1Table.getColumnModel().getColumn(1).setResizable(false);
            degreeY3S1Table.getColumnModel().getColumn(2).setResizable(false);
        }

        degreeY3S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        degreeY3S2Table.setToolTipText("This table can not be edited");
        degreeY3S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane39.setViewportView(degreeY3S2Table);
        if (degreeY3S2Table.getColumnModel().getColumnCount() > 0) {
            degreeY3S2Table.getColumnModel().getColumn(0).setResizable(false);
            degreeY3S2Table.getColumnModel().getColumn(1).setResizable(false);
            degreeY3S2Table.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout jPanel14Layout = new javax.swing.GroupLayout(jPanel14);
        jPanel14.setLayout(jPanel14Layout);
        jPanel14Layout.setHorizontalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane38, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane39)
        );
        jPanel14Layout.setVerticalGroup(
            jPanel14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel14Layout.createSequentialGroup()
                .addComponent(jScrollPane38, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane39, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        degreeTabbedPane.addTab("Year 3", jPanel14);

        degreeY4S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        degreeY4S1Table.setToolTipText("This table can not be edited");
        degreeY4S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane36.setViewportView(degreeY4S1Table);
        if (degreeY4S1Table.getColumnModel().getColumnCount() > 0) {
            degreeY4S1Table.getColumnModel().getColumn(0).setResizable(false);
            degreeY4S1Table.getColumnModel().getColumn(1).setResizable(false);
            degreeY4S1Table.getColumnModel().getColumn(2).setResizable(false);
        }

        degreeY4S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        degreeY4S2Table.setToolTipText("This table can not be edited");
        degreeY4S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane37.setViewportView(degreeY4S2Table);
        if (degreeY4S2Table.getColumnModel().getColumnCount() > 0) {
            degreeY4S2Table.getColumnModel().getColumn(0).setResizable(false);
            degreeY4S2Table.getColumnModel().getColumn(1).setResizable(false);
            degreeY4S2Table.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout jPanel15Layout = new javax.swing.GroupLayout(jPanel15);
        jPanel15.setLayout(jPanel15Layout);
        jPanel15Layout.setHorizontalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane36, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane37)
        );
        jPanel15Layout.setVerticalGroup(
            jPanel15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel15Layout.createSequentialGroup()
                .addComponent(jScrollPane36, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane37, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        degreeTabbedPane.addTab("Year 4", jPanel15);

        degreeY5S1Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        degreeY5S1Table.setToolTipText("This table can not be edited");
        degreeY5S1Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane34.setViewportView(degreeY5S1Table);
        if (degreeY5S1Table.getColumnModel().getColumnCount() > 0) {
            degreeY5S1Table.getColumnModel().getColumn(0).setResizable(false);
            degreeY5S1Table.getColumnModel().getColumn(1).setResizable(false);
            degreeY5S1Table.getColumnModel().getColumn(2).setResizable(false);
        }

        degreeY5S2Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Semester", "Course Code", "Grade"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        degreeY5S2Table.setToolTipText("This table can not be edited");
        degreeY5S2Table.getTableHeader().setReorderingAllowed(false);
        jScrollPane35.setViewportView(degreeY5S2Table);
        if (degreeY5S2Table.getColumnModel().getColumnCount() > 0) {
            degreeY5S2Table.getColumnModel().getColumn(0).setResizable(false);
            degreeY5S2Table.getColumnModel().getColumn(1).setResizable(false);
            degreeY5S2Table.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane34, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
            .addComponent(jScrollPane35)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addComponent(jScrollPane34, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane35, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        degreeTabbedPane.addTab("Year 5", jPanel16);

        notListedTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Course Code", "Semester Offered"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        notListedTable.setToolTipText("All required courses that are not in the plan of study or transcript");
        notListedTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane5.setViewportView(notListedTable);
        if (notListedTable.getColumnModel().getColumnCount() > 0) {
            notListedTable.getColumnModel().getColumn(0).setResizable(false);
            notListedTable.getColumnModel().getColumn(1).setResizable(false);
        }

        javax.swing.GroupLayout notListedPanelLayout = new javax.swing.GroupLayout(notListedPanel);
        notListedPanel.setLayout(notListedPanelLayout);
        notListedPanelLayout.setHorizontalGroup(
            notListedPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
        );
        notListedPanelLayout.setVerticalGroup(
            notListedPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
        );

        degreeTabbedPane.addTab("Not Listed", notListedPanel);

        incompleteTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Course Code", "In Plan of Study"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        incompleteTable.setToolTipText("All required courses that are currently not completed");
        incompleteTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane3.setViewportView(incompleteTable);
        if (incompleteTable.getColumnModel().getColumnCount() > 0) {
            incompleteTable.getColumnModel().getColumn(0).setResizable(false);
            incompleteTable.getColumnModel().getColumn(1).setResizable(false);
        }

        javax.swing.GroupLayout incompletePanelLayout = new javax.swing.GroupLayout(incompletePanel);
        incompletePanel.setLayout(incompletePanelLayout);
        incompletePanelLayout.setHorizontalGroup(
            incompletePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 503, Short.MAX_VALUE)
        );
        incompletePanelLayout.setVerticalGroup(
            incompletePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 222, Short.MAX_VALUE)
        );

        degreeTabbedPane.addTab("Incomplete", incompletePanel);

        degreeTabLabel.setText("Placeholder");

        gpaDegreeRefreshLabel.setText("Refresh");
        gpaDegreeRefreshLabel.setToolTipText("Refreshes information for the above jLabel, in case new information has been added");
        gpaDegreeRefreshLabel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gpaDegreeRefreshLabelActionPerformed(evt);
            }
        });

        checkRequirementsLabel.setText("Degree requirements met:");

        requirementsMetLabel.setText("Refresh");
        requirementsMetLabel.setToolTipText("Refreshes information for the above jLabel, in case new information has been added");
        requirementsMetLabel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                requirementsMetLabelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout degreePanelLayout = new javax.swing.GroupLayout(degreePanel);
        degreePanel.setLayout(degreePanelLayout);
        degreePanelLayout.setHorizontalGroup(
            degreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, degreePanelLayout.createSequentialGroup()
                .addGroup(degreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(degreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(degreePanelLayout.createSequentialGroup()
                            .addGap(241, 241, 241)
                            .addComponent(degreeTabLabel))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, degreePanelLayout.createSequentialGroup()
                            .addGap(8, 8, 8)
                            .addComponent(gpaCalculatorComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(gpaPrintLabel)))
                    .addGroup(degreePanelLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(gpaDegreeRefreshLabel)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(degreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(requirementsMetLabel)
                    .addComponent(checkRequirementsLabel))
                .addGap(124, 124, 124))
            .addGroup(degreePanelLayout.createSequentialGroup()
                .addGap(67, 67, 67)
                .addComponent(degreeTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 508, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(62, Short.MAX_VALUE))
        );
        degreePanelLayout.setVerticalGroup(
            degreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(degreePanelLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(degreeTabLabel)
                .addGap(16, 16, 16)
                .addGroup(degreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(gpaPrintLabel)
                    .addComponent(gpaCalculatorComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(checkRequirementsLabel))
                .addGap(1, 1, 1)
                .addGroup(degreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(gpaDegreeRefreshLabel)
                    .addComponent(requirementsMetLabel))
                .addGap(32, 32, 32)
                .addComponent(degreeTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(67, Short.MAX_VALUE))
        );

        studentTabbedPane.addTab("Degree", degreePanel);

        studentTabbedPane.setVisible(false);

        loginPromptLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        loginPromptLabel1.setText("Please login as a Student for additional functionality");

        javax.swing.GroupLayout workAreaPanelLayout = new javax.swing.GroupLayout(workAreaPanel);
        workAreaPanel.setLayout(workAreaPanelLayout);
        workAreaPanelLayout.setHorizontalGroup(
            workAreaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, workAreaPanelLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(studentTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 644, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11))
            .addGroup(workAreaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(workAreaPanelLayout.createSequentialGroup()
                    .addGap(155, 155, 155)
                    .addComponent(loginPromptLabel1)
                    .addContainerGap(155, Short.MAX_VALUE)))
        );
        workAreaPanelLayout.setVerticalGroup(
            workAreaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(workAreaPanelLayout.createSequentialGroup()
                .addComponent(studentTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 6, Short.MAX_VALUE))
            .addGroup(workAreaPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(workAreaPanelLayout.createSequentialGroup()
                    .addGap(211, 211, 211)
                    .addComponent(loginPromptLabel1)
                    .addContainerGap(215, Short.MAX_VALUE)))
        );

        jPanel3.setBackground(new java.awt.Color(102, 102, 102));
        jPanel3.setPreferredSize(new java.awt.Dimension(2, 0));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        menuBar.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        userMenu.setText("User");

        userSettingsMenu.setText("User Settings");
        userSettingsMenu.setToolTipText("Change user information");

        nameSettingMenuItem.setText("Change Name");
        nameSettingMenuItem.setToolTipText("Change student's name");
        nameSettingMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameSettingMenuItemActionPerformed(evt);
            }
        });
        userSettingsMenu.add(nameSettingMenuItem);

        degreeSettingsMenuItem.setText("Set Degree");
        degreeSettingsMenuItem.setToolTipText("Set/Change the student's degree and major");
        degreeSettingsMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                degreeSettingsMenuItemActionPerformed(evt);
            }
        });
        userSettingsMenu.add(degreeSettingsMenuItem);

        userMenu.add(userSettingsMenu);

        switchUserMenuItem.setText("Switch User");
        switchUserMenuItem.setToolTipText("Displays all other users, and will allow a new user to sign on");
        switchUserMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                switchUserMenuItemActionPerformed(evt);
            }
        });
        userMenu.add(switchUserMenuItem);

        createUserMenuItem.setText("Create New User");
        createUserMenuItem.setToolTipText("Creates a new user, and logs into that user if no current user is logged in");
        createUserMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                createUserMenuItemActionPerformed(evt);
            }
        });
        userMenu.add(createUserMenuItem);
        userMenu.add(userActionSeperator);

        adminLoginMenuItem.setText("Login As Admin");
        adminLoginMenuItem.setToolTipText("Login as a system administrator");
        adminLoginMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adminLoginMenuItemActionPerformed(evt);
            }
        });
        userMenu.add(adminLoginMenuItem);
        userMenu.add(exitSeparator);

        exitMenuItem.setText("Exit");
        exitMenuItem.setToolTipText("Exits the program. Current data IS NOT saved");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        userMenu.add(exitMenuItem);

        menuBar.add(userMenu);

        fileMenu.setText("File");

        saveMenuItem.setText("Save Data");
        saveMenuItem.setToolTipText("Saves the current state of your plan");
        saveMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(saveMenuItem);

        menuBar.add(fileMenu);

        aboutMenu.setText("About");

        aboutProgramMenuItem.setText("About Program");
        aboutProgramMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                aboutProgramMenuItemActionPerformed(evt);
            }
        });
        aboutMenu.add(aboutProgramMenuItem);

        helpMenuItem.setText("Help");
        helpMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                helpMenuItemActionPerformed(evt);
            }
        });
        aboutMenu.add(helpMenuItem);

        menuBar.add(aboutMenu);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(courseSearchAndSelectPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(workAreaPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(courseSearchAndSelectPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 467, Short.MAX_VALUE)
            .addComponent(workAreaPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void degreeSettingsMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_degreeSettingsMenuItemActionPerformed
        if(currentStudent != null) {
            String major = degreePrompt();
            if(major != null) {
                currentStudent.setMajor(major);

                dbConnect.deleteSavedStudent(currentStudent.getStudentNumber().toString(), currentStudent.getFullName());
                DBStudent student = new DBStudent(currentStudent.getStudentNumber().toString(), currentStudent.getFullName(), currentStudent.getMajor(), generateStudentCourses());
                dbConnect.saveStudent(student);
                /* Update state of the UI, in case the student has met the requirements for the new degree */
                setCreditsRemaining();
                setTables();
                checkRequirementsLabel.setText("Degree requirements met: " + checkRequirements());
            }
        } else {
            JOptionPane.showMessageDialog(new JFrame(), "Login to a student", "Error", 2);
        }
    }//GEN-LAST:event_degreeSettingsMenuItemActionPerformed

    private void aboutProgramMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_aboutProgramMenuItemActionPerformed
        JOptionPane.showMessageDialog(new JFrame(), "This program is designed to allow students to plan and track their degree progression.\n\nTools are provided for administrators.", "About", 1);
    }//GEN-LAST:event_aboutProgramMenuItemActionPerformed

    private void helpMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_helpMenuItemActionPerformed
        JOptionPane.showMessageDialog(new JFrame(), "Have you tried turning it off and back on again?", "Help", 1);
    }//GEN-LAST:event_helpMenuItemActionPerformed

    private void nameSettingMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameSettingMenuItemActionPerformed
        /* I elect for an if error check rather than a try catch, because I want the error caught before it goes to the prompt */
        if(currentStudent == null) {
            JOptionPane.showMessageDialog(new JFrame(), "Please create or login to a student", "Error", 2);
        }
        String name = namePrompt();
        String saveName = currentStudent.getFullName();
        currentStudent.setFirstName(name.split(" ")[0]);
        currentStudent.setLastName(name.split(" ")[1]);

        // Delete the existing save and place a new one
        dbConnect.deleteSavedStudent(currentStudent.getStudentNumber().toString(), saveName);
        DBStudent student = new DBStudent(currentStudent.getStudentNumber().toString(), currentStudent.getFullName(), currentStudent.getMajor(), generateStudentCourses());
        dbConnect.saveStudent(student);

        setLabelText();
    }//GEN-LAST:event_nameSettingMenuItemActionPerformed

    private void createUserMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createUserMenuItemActionPerformed
        Student temp = new Student(catalog);

        int studentID;
        String studentName;


        studentName = namePrompt();

        if(studentName == null) {
            return;
        }

        temp.setFirstName(studentName.split(" ")[0]);
        temp.setLastName(studentName.split(" ")[1]);

        studentID = idPrompt();

        if(studentID == -1) {
            return;
        }
        temp.setStudentNumber(studentID);

        /* All student ID's should be unique, but the database search won't account for that it seems */
        Integer key = temp.getStudentNumber();

        temp.setMajor(degreePrompt());

        if(currentStudent != null) {
            dbConnect.deleteSavedStudent(currentStudent.getStudentNumber().toString(), currentStudent.getFullName());
            DBStudent student = new DBStudent(currentStudent.getStudentNumber().toString(), currentStudent.getFullName(), currentStudent.getMajor(), generateStudentCourses());
            dbConnect.saveStudent(student);
        }

        studentTabbedPane.setVisible(true);

        currentStudent = temp;

        /* Code below is UI related information updates */
        populatePOSTables();
        populateTranscriptTables();
        populateDegreeTables();
        setLabelText();
        setCreditsRemaining();
        setTables();

        if(searchedCourse != null) {
            courseSelectionPane.setVisible(true);
        }

        checkRequirementsLabel.setText("Degree requirements met: " + checkRequirements());
//        } else {
//            JOptionPane.showMessageDialog(new JFrame(), "This user already exists (Duplicate ID's). Unable to override an existing user.\n\nIf you feel this is an error, please contact an administrator or technical support", "Error", 2);
//        }
    }//GEN-LAST:event_createUserMenuItemActionPerformed

    private void gpaCalculatorComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gpaCalculatorComboBoxActionPerformed
        gpaPrintLabel.setText(getGPAString());
    }//GEN-LAST:event_gpaCalculatorComboBoxActionPerformed

    private void plannedCreditsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_plannedCreditsButtonActionPerformed
         try {
            Credits creditCounter = new Credits(currentStudent, catalog);

            plannedCreditsLabel.setText("Total value of Planned Credits: " + creditCounter.getPlannedCredits());
        } catch(NullObjectException e) {
            JOptionPane.showMessageDialog(new JFrame(), "Please create or login to a student", "Error", 2);
        }
    }//GEN-LAST:event_plannedCreditsButtonActionPerformed

    private void passedCreditsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passedCreditsButtonActionPerformed
        try {
            Credits creditCounter = new Credits(currentStudent, catalog);

            passedCreditsLabel.setText("Total value of Passed Credits: " + creditCounter.getTranscriptCredits());
        } catch(NullObjectException e) {
            JOptionPane.showMessageDialog(new JFrame(), "Please create or login to a student", "Error", 2);
        }
    }//GEN-LAST:event_passedCreditsButtonActionPerformed

    private void courseSearchTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_courseSearchTextFieldKeyPressed
        if(evt.getKeyCode() != 10) {
            return;
        }

        try {
            searchedCourse = catalog.findCourse(courseSearchTextField.getText().toUpperCase());
        } catch(CourseNotFoundException e) {
            JOptionPane.showMessageDialog(new JFrame(), "Course not found. Please try another search.", "Error", 2);
            return;
        }

        DefaultTableModel model = (DefaultTableModel) coursePrerequisiteTable.getModel();
        /*
         * Clean up the prerequisite table, from end of the table to the start.
         * If the table is longer than 5 rows, the extras are removed. Otherwise, a row is set to null.
         */
        for(int i = model.getRowCount()-1; i > -1; i--) {
            if(i >= 5) {
                model.removeRow(i);
            } else {
                model.setValueAt(null, i, 0);
                model.setValueAt(null, i, 1);
            }
        }

        courseInfoTextArea.setText("Course: " + searchedCourse.getCourseCode() + "\n\nOffered: " + searchedCourse.getSemesterOffered() + "\n\nCredits: " + searchedCourse.getCourseCredit());

        ArrayList<Course> prerequisites = searchedCourse.getPrerequisites();
        int row = 0;

        for(Course course: prerequisites){
            DefaultTableModel model2 = (DefaultTableModel) coursePrerequisiteTable.getModel();
            if(row >= 5) {
                model2.addRow(new Object[]{null, null}); // Add a new row to the table if there are more than 5 prereq courses!
            }
            model2.setValueAt(course.getCourseCode(), row, 0);
            model2.setValueAt(course.getSemesterOffered(), row, 1);
            row ++;
        }

        if(currentStudent != null) {
            addToLabel.setVisible(true);
            courseSelectionPane.setVisible(true);
        }
    }//GEN-LAST:event_courseSearchTextFieldKeyPressed

    private void addToTranscriptButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addToTranscriptButtonActionPerformed
        String semester = semesterPrompt();

        if(semester == null) {
            return;
        }

        String grade = gradePrompt();
        if(grade == null) {
            return;
        }

        try {
            currentStudent.addAttempt(searchedCourse.getCourseCode(), semester, grade);
        } catch (CourseNotFoundException | CourseAlreadyExistsException ex) {
            JOptionPane.showMessageDialog(new JFrame(), "Course could not be added to the transcript (Tip: A course can only be in the plan once)", "Error", 2);
            return;
        }

        populateTranscriptTables();
        populateDegreeTables();
        setTables();
    }//GEN-LAST:event_addToTranscriptButtonActionPerformed

    private void addToPlannedButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addToPlannedButtonActionPerformed
        String semester = semesterPrompt();

        if(semester == null) {
            return;
        }

        try {
            currentStudent.addPlanned(searchedCourse.getCourseCode(), semester);
        } catch (CourseAlreadyExistsException ex) {
            JOptionPane.showMessageDialog(new JFrame(), "Course could not be added to the transcript (Tip: A course can only be in the plan once)", "Error", 2);
            return;
        }

        populatePOSTables();
        populateDegreeTables();
        setTables();
    }//GEN-LAST:event_addToPlannedButtonActionPerformed

    private void clearAreaButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearAreaButtonActionPerformed
        courseInfoTextArea.setText(DEFAULT_TEXT);
        courseSearchTextField.setText(HINT_TEXT);
        courseSelectionPane.setVisible(false);
        addToLabel.setVisible(false);

        DefaultTableModel model = (DefaultTableModel) coursePrerequisiteTable.getModel();
        /*
         * Clean up the prerequisite table, from end of the table to the start.
         * If the table is longer than 5 rows, the extras are removed. Otherwise, a row is set to null.
         */
        for(int i = model.getRowCount()-1; i > -1; i--) {
            if(i >= 5) {
                model.removeRow(i);
            } else {
                model.setValueAt(null, i, 0);
                model.setValueAt(null, i, 1);
            }
        }
    }//GEN-LAST:event_clearAreaButtonActionPerformed

    private void courseSearchTextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_courseSearchTextFieldFocusGained
        if(courseSearchTextField.getText().equals(HINT_TEXT)) {
            courseSearchTextField.setText("");
        }
    }//GEN-LAST:event_courseSearchTextFieldFocusGained

    private void courseSearchTextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_courseSearchTextFieldFocusLost
        if(courseSearchTextField.getText().equals("")) {
            courseSearchTextField.setText(HINT_TEXT);
        }
    }//GEN-LAST:event_courseSearchTextFieldFocusLost

    private void gpaDegreeRefreshLabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gpaDegreeRefreshLabelActionPerformed
        gpaPrintLabel.setText(getGPAString());
    }//GEN-LAST:event_gpaDegreeRefreshLabelActionPerformed

    private void requirementsMetLabelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_requirementsMetLabelActionPerformed
        checkRequirementsLabel.setText("Degree requirements met: " + checkRequirements());
    }//GEN-LAST:event_requirementsMetLabelActionPerformed

    private void adminLoginMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminLoginMenuItemActionPerformed
        String login = JOptionPane.showInputDialog(new JFrame(), "Please enter password (Hint: It is \"admin\"): ", "Password", -1);

        if(login == null) {
            return;
        }

        if(login.equals("admin")) {
            Administrator admin = new Administrator(catalog); //Gonna have to re-read the database after returning
            admin.setVisible(true);
        }
    }//GEN-LAST:event_adminLoginMenuItemActionPerformed

    private void refreshNumCreditsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshNumCreditsButtonActionPerformed
        setCreditsRemaining();
    }//GEN-LAST:event_refreshNumCreditsButtonActionPerformed

    private void saveMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveMenuItemActionPerformed
        dbConnect.deleteSavedStudent(currentStudent.getStudentNumber().toString(), currentStudent.getFullName());
        DBStudent student = new DBStudent(currentStudent.getStudentNumber().toString(), currentStudent.getFullName(), currentStudent.getMajor(), generateStudentCourses());
        dbConnect.saveStudent(student);
    }//GEN-LAST:event_saveMenuItemActionPerformed

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        dbConnect.deleteSavedStudent(currentStudent.getStudentNumber().toString(), currentStudent.getFullName());
        DBStudent student = new DBStudent(currentStudent.getStudentNumber().toString(), currentStudent.getFullName(), currentStudent.getMajor(), generateStudentCourses());
        dbConnect.saveStudent(student);
        super.dispose();
        System.exit(0);
    }//GEN-LAST:event_exitMenuItemActionPerformed

    private void switchUserMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_switchUserMenuItemActionPerformed
        String id, name;

        id = JOptionPane.showInputDialog(new JFrame(), "Enter the ID of the student to load", "Select User", -1);
        if(id == null) {
            return;
        }

        name = JOptionPane.showInputDialog(new JFrame(), "Enter the Name (First Last) of the student to load)", "Select User", -1);

        if(name == null) {
            return;
        }

        DBStudent returnedStudent;

        returnedStudent = dbConnect.loadStudent(id, name);

        if(returnedStudent == null || returnedStudent.getName() == null) {
            return;
        }

        if(currentStudent != null) {
            dbConnect.deleteSavedStudent(currentStudent.getStudentNumber().toString(), currentStudent.getFullName());
            DBStudent student = new DBStudent(currentStudent.getStudentNumber().toString(), currentStudent.getFullName(), currentStudent.getMajor(), generateStudentCourses());
            dbConnect.saveStudent(student);
        }

        currentStudent = new Student(catalog);

        currentStudent.setFirstName(returnedStudent.getName().split(" ")[0]);
        currentStudent.setLastName(returnedStudent.getName().split(" ")[1]);
        currentStudent.setStudentNumber(Integer.parseInt(returnedStudent.getId()));
        currentStudent.setMajor(returnedStudent.getDegree());
        reassembleStudent(returnedStudent.getCourses());

        studentTabbedPane.setVisible(true);
        setLabelText();
        setCreditsRemaining();
        setTables();

        populatePOSTables();
        populateTranscriptTables();
        populateDegreeTables();
        setTables();

        if(searchedCourse != null) {
            courseSelectionPane.setVisible(true);
        }
    }//GEN-LAST:event_switchUserMenuItemActionPerformed

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        /* Populate a list of all the tables in the student menu for easy acces later */
        plannedTables.add(posY1S1Table);
        plannedTables.add(posY1S2Table);
        plannedTables.add(posY2S1Table);
        plannedTables.add(posY2S2Table);
        plannedTables.add(posY3S1Table);
        plannedTables.add(posY3S2Table);
        plannedTables.add(posY4S1Table);
        plannedTables.add(posY4S2Table);
        plannedTables.add(posY5S1Table);
        plannedTables.add(posY5S2Table);

        transcriptTables.add(transcriptY1S1Table);
        transcriptTables.add(transcriptY1S2Table);
        transcriptTables.add(transcriptY2S1Table);
        transcriptTables.add(transcriptY2S2Table);
        transcriptTables.add(transcriptY3S1Table);
        transcriptTables.add(transcriptY3S2Table);
        transcriptTables.add(transcriptY4S1Table);
        transcriptTables.add(transcriptY4S2Table);
        transcriptTables.add(transcriptY5S1Table);
        transcriptTables.add(transcriptY5S2Table);

        degreeTables.add(degreeY1S1Table);
        degreeTables.add(degreeY1S2Table);
        degreeTables.add(degreeY2S1Table);
        degreeTables.add(degreeY2S2Table);
        degreeTables.add(degreeY3S1Table);
        degreeTables.add(degreeY3S2Table);
        degreeTables.add(degreeY4S1Table);
        degreeTables.add(degreeY4S2Table);
        degreeTables.add(degreeY5S1Table);
        degreeTables.add(degreeY5S2Table);
    }//GEN-LAST:event_formComponentShown

    /**
     * A helper method to assist in prompting the user for a user name.
     *
     * @return
     */
    protected String namePrompt() {
        String studentName = JOptionPane.showInputDialog(new JFrame(), "Please enter your name (Style: First Last): ", "Name Entry", -1);

        if(studentName == null) {
            return studentName;
        }

        String[] fullName = studentName.toUpperCase().split(" ");
        if(fullName.length != 2 || fullName[0].length() == 0 || fullName[1].length() == 0) {
            JOptionPane.showMessageDialog(new JFrame(), "Invalid input. Please try again.", "Error", 2);
            studentName = namePrompt();
        }

        return studentName;
    }

    /**
     * A helper method to assist in prompting the user for a student ID.
     *
     * @return
     */
    protected int idPrompt() {
        String input = JOptionPane.showInputDialog(new JFrame(), "Please enter a new ID:", "ID Entry", -1);
        int id = 0;

        if(input == null) {
            return -1;
        }

        try {
            id = Integer.parseInt(input);
            if(id <= 0) {
                JOptionPane.showMessageDialog(new JFrame(), "Invalid input. ID must be greater than 0. Please try again.", "Error", 2);
                id = idPrompt();
            }
        } catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(new JFrame(), "Invalid input. Expected value is an integer. Please try again.", "Error", 2);
            id = idPrompt();
        }

        return id;
    }

    /**
     * A helper method to assist in prompting the user for a semester.
     *
     * @return
     */
    protected String semesterPrompt() {
        String semester = JOptionPane.showInputDialog(new JFrame(), "Please enter the Semester (F or W, followed by 2 integers): ", "Semester Entry", -1);
        boolean isValid = true, isOffered = true;

        if(semester == null) {
            return semester;
        }

        semester = semester.toUpperCase();
        if(semester.length() != 3) {
            isValid = false;
        } else if(semester.charAt(0) != 'W' && semester.charAt(0) != 'F') {
            isValid = false;
        } else if(semester.charAt(1) < '0' || semester.charAt(1) > '9') {
            isValid = false;
        } else if(semester.charAt(2) < '0' || semester.charAt(2) > '9') {
            isValid = false;
        } else if(semester.charAt(0) != searchedCourse.getSemesterOffered().charAt(0) && searchedCourse.getSemesterOffered().charAt(0) != 'B') {
            isOffered = false;
        }

        if(!isValid) {
            JOptionPane.showMessageDialog(new JFrame(), "Invalid input. Please try again.", "Error", 2);
            semester = semesterPrompt();
        } else if(!isOffered) {
            JOptionPane.showMessageDialog(new JFrame(), "Invalid input. Course is not offered during that semester.", "Error", 2);
            semester = semesterPrompt();
        }

        return semester;
    }

    /**
     * A helper method to assist in prompting the user for a grade.
     *
     * @return
     */
    protected String gradePrompt() {
        String grade = JOptionPane.showInputDialog(new JFrame(), "Please enter your grade (P, F, INC, MNR or a double): ", "Grade Entry", -1);

        if(grade == null){
            return grade;
        }

        if(grade.equalsIgnoreCase("F") || grade.equalsIgnoreCase("P") || grade.equalsIgnoreCase("INC") || grade.equalsIgnoreCase("MNR")) {
            grade = grade.toUpperCase();
            return grade;
        } else {
            try {
                if(Double.parseDouble(grade) < 0 || Double.parseDouble(grade) > 100) { // Invalid input makes it through
                    JOptionPane.showMessageDialog(new JFrame(), "Invalid input. Please try again.", "Error", 2);
                    grade = gradePrompt();
                }
            } catch(NumberFormatException e) {
                grade = gradePrompt();
            }
        }
        return grade;
    }

    /**
     * Prompts the user to give their degree and major if applicable.
     *
     * @return
     */
    protected String degreePrompt() {
        String degree = JOptionPane.showInputDialog(new JFrame(), "Which Degree are you enrolled in - Honours or General?: ", "Degree Selector", -1);
        String major = null;

        if(degree == null ) {
            JOptionPane.showMessageDialog(new JFrame(), "Login to a student", "Error", 2);
            return major;
        }
        if(degree.equalsIgnoreCase("Honours")) {

            boolean valid = false;

            do {
                major = JOptionPane.showInputDialog(new JFrame(), "Which major are you - CS or SENG?: ", "Major Selector", -1);
                if(!major.equalsIgnoreCase("CS") && !major.equalsIgnoreCase("SENG")) {
                    JOptionPane.showMessageDialog(new JFrame(), "Invalid input. Please try again.", "Error", 2);
                } else {
                    valid = true;
                }
            } while(!valid);

            return major.toUpperCase();

        } else if(degree.equalsIgnoreCase("General")) {
            return "BCG";
        } else {
            JOptionPane.showMessageDialog(new JFrame(), "Invalid input. Please try again.", "Error", 2);
            major = degreePrompt();
            return major;
        }
    }

    /**
     * Sets the text for the tab labels.
     */
    protected void setLabelText() {
        transcriptTabLabel.setText(currentStudent.getFullName() + "'s Course Transcript");
        planOfStudyTabLabel.setText(currentStudent.getFullName() + "'s Plan of Study");
        degreeTabLabel.setText(currentStudent.getFullName() + "'s Degree Info");
    }

    /**
     * Returns a String representing text for the gpaString in the Degree tab.
     *
     * @return
     */
    protected String getGPAString() {
        try {
            Credits creditCounter = new Credits(currentStudent, catalog);

            switch (gpaCalculatorComboBox.getSelectedItem().toString()) {
                case "Calculate GPA":
                    return ("GPA: " + creditCounter.calculateGPA() + "%");
                case "Calculate CIS GPA":
                    return ("GPA: " + creditCounter.calculateCISGPA() + "%");
                case "Calculate last 10 GPA":
                    return ("GPA: " + creditCounter.calculateLastTenGPA() + "%");
                default:
                    return ("GPA: ");
            }
        } catch(NullObjectException e) {
            return ("GPA: ");
            // Do nothing
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(new JFrame(), "Student or catalog not initialized", "Error", 2);
            return ("GPA: ");
        }
    }

    /**
     * Returns a boolean representing if the the student has met the degree requirements.
     *
     * @return
     */
    protected boolean checkRequirements() {
        ArrayList<Course> allTheCoursesPlannedAndTaken = createTranscriptList();
        Degree temp;
        String major = currentStudent.getMajor();
        boolean returnedValue = false;

        switch(major) {
            case "SENG":
                temp = new SEng();
                returnedValue = temp.meetsRequirements(allTheCoursesPlannedAndTaken);
                calculateAverage();
                break;
            case "CS":
                temp = new CS();
                returnedValue = temp.meetsRequirements(allTheCoursesPlannedAndTaken);
                calculateAverage();
                break;
            case "BCG":
                temp = new BCG();
                returnedValue = temp.meetsRequirements(allTheCoursesPlannedAndTaken);
                break;
        }
        return returnedValue;
    }

    /**
     * Returns a boolean representing if the student has maintained a high enough average.
     * Calculates the CIS and AOA averages. If either is too low, false is returned.
     *
     * @return
     */
    protected boolean calculateAverage() {
        int cisCount = 0, aoaCount = 0;
        double cisGrade = 0, aoaGrade = 0;

        /* Since Degree no longer has this information, I elect to do the calculations in house */
        for(Attempt attempt: currentStudent.getTranscript().values()) {
            if(attempt.getCourseAttempted().getCourseCode().startsWith("CIS") || attempt.getCourseAttempted().getCourseCode().startsWith("MATH*1200") || attempt.getCourseAttempted().getCourseCode().startsWith("STAT*2040")) {
                if(!attempt.getAttemptGrade().equals("F") && !attempt.getAttemptGrade().equals("P") && !attempt.getAttemptGrade().equals("MNR") && !attempt.getAttemptGrade().equals("INC")) {
                    cisGrade += Double.parseDouble(attempt.getAttemptGrade());
                    cisCount ++;
                }
            } else {
                if(!attempt.getAttemptGrade().equals("F") && !attempt.getAttemptGrade().equals("P") && !attempt.getAttemptGrade().equals("MNR") && !attempt.getAttemptGrade().equals("INC")) {
                    aoaGrade += Double.parseDouble(attempt.getAttemptGrade());
                    aoaCount ++;
                }
            }
        }

        if(((aoaGrade/aoaCount) >= 60) && ((cisGrade/cisCount) >= 70)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Returns an ArrayList of courses representing all planned and passed courses.
     *
     * @return
     */
    protected ArrayList<Course> createArrayList() {
        ArrayList<Course> courses = new ArrayList<>();

        for(String code: currentStudent.getPlanned().keySet()) {
            try {
                courses.add(catalog.findCourse(code));
            } catch (CourseNotFoundException ex) {
            }
        }

        for(Attempt attempt : currentStudent.getTranscript().values()) {
            try {
                if(attempt.getAttemptGrade().equals("P") || Double.parseDouble(attempt.getAttemptGrade()) >= 50) {
                    courses.add(catalog.findCourse(attempt.getCourseAttempted().getCourseCode()));
                }
            } catch (CourseNotFoundException | NumberFormatException ex) {
            }
        }
        return courses;
    }

    /**
     * Returns an ArrayList representing a list of all passed courses in the students transcript.
     *
     * @return
     */
    protected ArrayList<Course> createTranscriptList() {
        ArrayList<Course> courses = new ArrayList<>();

        for(Attempt attempt : currentStudent.getTranscript().values()) {
            if(attempt.getAttemptGrade().equals("P") || Double.parseDouble(attempt.getAttemptGrade()) >= 50) {
                try {
                    /* Finding the course again is arguable redundent, but I'm being defensive */
                    courses.add(catalog.findCourse(attempt.getCourseAttempted().getCourseCode()));
                } catch (CourseNotFoundException ex) {
                }
            }
        }

        return courses;
    }

    /**
     * Sets/Updates the Missing Prerequisites table in Plan, as well as the incomplete and not listed tables in Degree.
     * The logic in this method is a old, convoluted and general nasty. A refactor would be nice, but time constraints.
     */
    protected void setTables() {
        ArrayList<Course> degreeRequiredCourses = null;
        int row = 0;

        switch(currentStudent.getMajor()) {
            case "CS":
                degreeRequiredCourses = CS.remainingRequiredCourses(createTranscriptList());
                break;
            case "SENG":
                degreeRequiredCourses = SEng.remainingRequiredCourses(createTranscriptList());
                break;
            case "BCG":
                degreeRequiredCourses = BCG.remainingRequiredCourses(createTranscriptList());
                break;
        }

        // Clean up this table before starting to fill it again
        DefaultTableModel model = (DefaultTableModel) missingCoursesTable.getModel();
            for(int i = model.getRowCount()-1; i > -1; i--) {
                model.removeRow(i);
        }
        // Missing Prerequisites
        Map<String, Course> toAdd = new HashMap<>();
        for(String courseCode : currentStudent.getPlanned().keySet()) { // All courses in PoS

            ArrayList<Course> coursePrerequisites;
            try {
                coursePrerequisites = catalog.findCourse(courseCode).getPrerequisites();
            } catch (CourseNotFoundException ex) {
                continue;
            }

            for(Course course : coursePrerequisites) { // All prerequisite courses for said course

                boolean add = true;
                for(Course studentCourse : createArrayList()) { // Check if that course is in the PoS already or transcipt
                    if(studentCourse.getCourseCode().equals(course.getCourseCode())){
                        add = false;
                    }
                }

                /* If the course needs to be added to the missing prereq table, then add it */
                if(add) {
                    toAdd.put(course.getCourseCode(), course);
                }
            }
        }

        for(Course tempCourse : toAdd.values()) {
            model.addRow(new String[2]);

            model.setValueAt(tempCourse.getCourseCode(), row, 0);
            model.setValueAt(tempCourse.getSemesterOffered(), row, 1);
            row ++;
        }

        row = 0;
        // Required Courses not listed
        DefaultTableModel model2 = (DefaultTableModel) notListedTable.getModel();
        for(Course course : degreeRequiredCourses) { // All degree required courses
            boolean add = true;
            for(Course studentCourse : createArrayList()) { // Check if they are planned or completed
                if(studentCourse.getCourseCode().equals(course.getCourseCode())){
                    add = false;
                }
            }

            if(add) {
                model2.addRow(new String[2]);

                model2.setValueAt(course.getCourseCode(), row, 0);
                model2.setValueAt(course.getSemesterOffered(), row, 1);
                row ++;
            }
        }
        /* Clean up rows that are no longer valid */
        for(int i = model2.getRowCount()-1; i > row-1; i--) {
            model2.removeRow(i);
        }

        row = 0;
        // Incomplete required courses

        DefaultTableModel model3 = (DefaultTableModel) incompleteTable.getModel();
        for(Course course : degreeRequiredCourses) { // All degree required courses
            boolean add = true;
            for(Course transcriptCourse : createTranscriptList()) {
                if(transcriptCourse.getCourseCode().equals(course.getCourseCode())) {
                    add = false;
                }
            }

            if(add) {
                model3.addRow(new String[2]);

                model3.setValueAt(course.getCourseCode(), row, 0);
                if(currentStudent.getPlanned().containsKey(course.getCourseCode())) {
                    model3.setValueAt("Yes", row, 1);
                } else {
                    model3.setValueAt("No", row, 1);
                }

                row ++;
            }
        }
        /* Clean up rows that are no longer valid */
        for(int i = model3.getRowCount()-1; i > row-1; i--) {
            model3.removeRow(i);
        }
    }

    /**
     * Sets the label for the number of credits remaining to be added.
     */
    protected void setCreditsRemaining() {
        switch(currentStudent.getMajor()) {
            case "SEng":
                numCreditsRemainingLabel.setText("Number of credits to have at least 20: " + new SEng().numberOfCreditsRemaining(createArrayList()));
                break;
            case "CS":
                numCreditsRemainingLabel.setText("Number of credits to have at least 20: " + new CS().numberOfCreditsRemaining(createArrayList()));
                break;
            case "BCG":
                numCreditsRemainingLabel.setText("Number of credits to have at least 15: " + new BCG().numberOfCreditsRemaining(createArrayList()));
                break;
        }
    }

    /**
     * A helper function that cleans all POS tables, and then hands the data for each table to load to populatePOSTable.
     */
    protected void populatePOSTables() {
        // Make sure the tables are empty. This avoids any left over data being left in the table!
        cleanPOSTables();

        /*
         * The values of the entrySet of the Map returned from getPlanned (Represents semester)
         * is mapped to a key of type Semester in the new termCourses map.
         * The key of the entrySet from getPlanned (courseCode) is mapped to a flat list
         * in the resulting map and is stored as its value.
         * Essentially, this swaps the key and value around, while providing a
         * way to compare and sort semesters for later usage.
         */
        Map<Semester, List<String>> termCourses;
        termCourses = currentStudent.getPlanned().entrySet().stream()
                .collect(
                        Collectors.groupingBy(
                                e -> Semester.fromString(e.getValue()),
                                Collectors.mapping(e -> e.getKey(), Collectors.toList())));

        int termIndex = 0;
        for(Semester key : termCourses.keySet().stream().sorted().collect(Collectors.toList())) {
            populatePOSTable(key, termCourses.get(key), plannedTables.get(termIndex));

            termIndex++;
        }
    }

    /**
     * Populates the data in the plan of study tables with all currently planned courses.
     *
     * @param semester
     * @param courseCodes
     * @param posTable
     */
    protected void populatePOSTable(Semester semester, List<String> courseCodes, JTable posTable) {
        DefaultTableModel posModel = (DefaultTableModel) posTable.getModel();

        for(int i = 0; i < courseCodes.size(); i++) {
            posModel.addRow(new String[2]);
            posModel.setValueAt(semester.toString(), i, 0);
            posModel.setValueAt(courseCodes.get(i), i, 1);
        }
    }

    /**
     * A helper function that cleans all transcript tables, and then hands the data for each table to load to populateTranscriptTable.
     */
    protected void populateTranscriptTables() {
        cleanTranscriptTables();

        /*
         * Read all the semesters planned, and will group them by semester, which act as keys for a map.
         * This map will hold an List of all course code planned during a given semester.
         */
        Map<Semester, List<Attempt>> termCourses;
        termCourses = currentStudent.getTranscript().values().stream()
                .collect(Collectors.groupingBy(s -> Semester.fromString(s.getSemesterTaken())));

        int termIndex = 0;
        for(Semester key : termCourses.keySet().stream().sorted().collect(Collectors.toList())) {
            populateTranscriptTable(key, termCourses.get(key), transcriptTables.get(termIndex));

            termIndex++;
        }
    }

    /**
     * Populates all the transcript tables with all attempted/completed courses.
     *
     * @param semester
     * @param courseCodes
     * @param transcriptTable
     */
    protected void populateTranscriptTable(Semester semester, List<Attempt> courseCodes, JTable transcriptTable) {
        DefaultTableModel transcriptModel = (DefaultTableModel) transcriptTable.getModel();

        for(int i = 0; i < courseCodes.size(); i++) {
            transcriptModel.addRow(new String[3]);
            transcriptModel.setValueAt(semester.toString(), i, 0);
            transcriptModel.setValueAt(courseCodes.get(i).getCourseAttempted().getCourseCode(), i, 1);
            transcriptModel.setValueAt(courseCodes.get(i).getAttemptGrade(), i, 2);
        }
    }

    /**
     * Creates an ArrayList of attempt objects which is the merging of both the plan of study and transcript.
     */
    protected void populateDegreeTables() {
        ArrayList<Attempt> attempts = new ArrayList<>();
        attempts.addAll(currentStudent.getTranscript().values());

        cleanDegreeTables();

        /*
         * An anonymous in line function is required to resolve the try-catch :( How disappointing
         * Otherwise, all of the elements in the entrySet for get planned are Mapped to an Attempt and grouped into an ArrayList
         */
        attempts.addAll(currentStudent.getPlanned().entrySet().stream()
                .map(e -> {
                        Course course;
                        try{
                            course = catalog.findCourse(e.getKey());
                        } catch(CourseNotFoundException ex) {
                            course = new Course();
                        }

                        return new Attempt(/* grade = */null, e.getValue(), course);
                    })
                .collect(Collectors.toList()));

        /*
         * This takes all the attempt object in the list and collects them into a flat list of attempts
         * This map is keyed on semesters. All keys are distinct, as a map is used
         */
        Map<Semester, List<Attempt>> allCourses = attempts.stream()
                .collect(Collectors.groupingBy(s -> Semester.fromString(s.getSemesterTaken())));

        int termIndex = 0;;
        for(Semester semester : allCourses.keySet().stream().sorted().collect(Collectors.toList())) {
            populateDegreeTable(allCourses.get(semester), degreeTables.get(termIndex));
            termIndex ++;
        }
    }

    /**
     * This populates the relevant data in the Degree tables.
     *
     * @param attempts
     * @param degreeTable
     */
    protected void populateDegreeTable(List<Attempt> attempts, JTable degreeTable) {
        DefaultTableModel degreeModel = (DefaultTableModel) degreeTable.getModel();

        int row = 0;
        for(int i = 0; i < attempts.size(); i++) {
            degreeModel.addRow(new String[3]);
            degreeModel.setValueAt(attempts.get(i).getSemesterTaken(), i, 0);
            degreeModel.setValueAt(attempts.get(i).getCourseAttempted().getCourseCode(), i, 1);
            degreeModel.setValueAt(attempts.get(i).getAttemptGrade(), i, 2);
            row ++;
        }
    }

    /**
     * A helper function that cleans all POS tables.
     */
    protected void cleanPOSTables() {
        plannedTables.stream().map((table) -> (DefaultTableModel) table.getModel()).forEach((model) -> {
            for(int i = model.getRowCount()-1; i >=0; i--) {
                model.removeRow(i);
            }
        });
    }

    /**
     * A helper function that cleans all transcript tables.
     */
    protected void cleanTranscriptTables() {
        transcriptTables.stream().map((table) -> (DefaultTableModel) table.getModel()).forEach((model) -> {
            for(int i = model.getRowCount()-1; i >=0; i--) {
                model.removeRow(i);
            }
        });
    }

    /**
     * Returns an arraylist of strings representing the courses a student has taken.
     *
     * @return
     */
    protected ArrayList<String> generateStudentCourses() {
        ArrayList<String> toReturn = new ArrayList<>();

        if (currentStudent == null) {
            return toReturn;
        }

        // Code_semester. This will represent a planned course
        currentStudent.getPlanned().entrySet().stream().forEach((entry) -> {
            toReturn.add(entry.getKey() + "_" + entry.getValue());
        });

        // code_semester_grade will be an attempted course
        currentStudent.getTranscript().entrySet().stream().forEach((entry) -> {

            toReturn.add(entry.getValue().getCourseAttempted().getCourseCode() + "_" + entry.getValue().getSemesterTaken() + "_" + entry.getValue().getAttemptGrade());
        });
        return toReturn;
    }

    /**
     * Reassembles a student's plan and transcript based on the passed argument.
     *
     * @param courses
     */
    protected void reassembleStudent(ArrayList<String> courses) {
        for(String course : courses) {
            String[] splitCourse = course.split("_");
            if(splitCourse.length == 2) {
                try {
                    currentStudent.addPlanned(splitCourse[0], splitCourse[1]);
                } catch (CourseAlreadyExistsException ex) {
                }
            } else if(splitCourse.length == 3) {
                try {
                    currentStudent.addAttempt(splitCourse[0], splitCourse[1], splitCourse[2]);
                } catch (CourseAlreadyExistsException | CourseNotFoundException ex) {
                }
            }
        }
    }
    /**
     * A helper function that cleans all degree tables.
     */
    protected void cleanDegreeTables() {
        degreeTables.stream().map((table) -> (DefaultTableModel) table.getModel()).forEach((model) -> {
            for(int i = model.getRowCount()-1; i >=0; i--) {
                model.removeRow(i);
            }
        });
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Planner.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Planner.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Planner.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Planner.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Planner().setVisible(true);
            }
        });
    }

    @Override
    public String toString() {
        return "This is a GUI for planner";
    }

    @Override
    public boolean equals(Object o) {
        if(o == null) {
            return false;
        } else if(o instanceof Planner){
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenu aboutMenu;
    private javax.swing.JMenuItem aboutProgramMenuItem;
    private javax.swing.JLabel addToLabel;
    private javax.swing.JButton addToPlannedButton;
    private javax.swing.JButton addToTranscriptButton;
    private javax.swing.JMenuItem adminLoginMenuItem;
    private javax.swing.JLabel checkRequirementsLabel;
    private javax.swing.JButton clearAreaButton;
    private javax.swing.JTextArea courseInfoTextArea;
    private javax.swing.JLabel coursePrerequisiteLabel;
    private javax.swing.JTable coursePrerequisiteTable;
    private javax.swing.JPanel courseSearchAndSelectPanel;
    private javax.swing.JLabel courseSearchLabel;
    private javax.swing.JTextField courseSearchTextField;
    private javax.swing.JPanel courseSelectionPane;
    private javax.swing.JMenuItem createUserMenuItem;
    private javax.swing.JPanel degreePanel;
    private javax.swing.JMenuItem degreeSettingsMenuItem;
    private javax.swing.JLabel degreeTabLabel;
    private javax.swing.JTabbedPane degreeTabbedPane;
    private javax.swing.JTable degreeY1S1Table;
    private javax.swing.JTable degreeY1S2Table;
    private javax.swing.JTable degreeY2S1Table;
    private javax.swing.JTable degreeY2S2Table;
    private javax.swing.JTable degreeY3S1Table;
    private javax.swing.JTable degreeY3S2Table;
    private javax.swing.JTable degreeY4S1Table;
    private javax.swing.JTable degreeY4S2Table;
    private javax.swing.JTable degreeY5S1Table;
    private javax.swing.JTable degreeY5S2Table;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JPopupMenu.Separator exitSeparator;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JComboBox<String> gpaCalculatorComboBox;
    private javax.swing.JButton gpaDegreeRefreshLabel;
    private javax.swing.JLabel gpaPrintLabel;
    private javax.swing.JMenuItem helpMenuItem;
    private javax.swing.JPanel incompletePanel;
    private javax.swing.JTable incompleteTable;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JDialog jDialog2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane14;
    private javax.swing.JScrollPane jScrollPane15;
    private javax.swing.JScrollPane jScrollPane16;
    private javax.swing.JScrollPane jScrollPane17;
    private javax.swing.JScrollPane jScrollPane18;
    private javax.swing.JScrollPane jScrollPane19;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane20;
    private javax.swing.JScrollPane jScrollPane21;
    private javax.swing.JScrollPane jScrollPane22;
    private javax.swing.JScrollPane jScrollPane23;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane34;
    private javax.swing.JScrollPane jScrollPane35;
    private javax.swing.JScrollPane jScrollPane36;
    private javax.swing.JScrollPane jScrollPane37;
    private javax.swing.JScrollPane jScrollPane38;
    private javax.swing.JScrollPane jScrollPane39;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane40;
    private javax.swing.JScrollPane jScrollPane41;
    private javax.swing.JScrollPane jScrollPane42;
    private javax.swing.JScrollPane jScrollPane43;
    private javax.swing.JScrollPane jScrollPane44;
    private javax.swing.JScrollPane jScrollPane45;
    private javax.swing.JScrollPane jScrollPane46;
    private javax.swing.JScrollPane jScrollPane47;
    private javax.swing.JScrollPane jScrollPane48;
    private javax.swing.JScrollPane jScrollPane49;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane50;
    private javax.swing.JScrollPane jScrollPane51;
    private javax.swing.JScrollPane jScrollPane52;
    private javax.swing.JScrollPane jScrollPane53;
    private javax.swing.JLabel loginPromptLabel1;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JPanel missingCoursesPanel;
    private javax.swing.JTable missingCoursesTable;
    private javax.swing.JMenuItem nameSettingMenuItem;
    private javax.swing.JPanel notListedPanel;
    private javax.swing.JTable notListedTable;
    private javax.swing.JLabel numCreditsRemainingLabel;
    private javax.swing.JButton passedCreditsButton;
    private javax.swing.JLabel passedCreditsLabel;
    private javax.swing.JPanel planOfStudyPanel;
    private javax.swing.JLabel planOfStudyTabLabel;
    private javax.swing.JTabbedPane planOfStudyTabbedPane;
    private javax.swing.JButton plannedCreditsButton;
    private javax.swing.JLabel plannedCreditsLabel;
    private javax.swing.JPanel posY1Panel;
    private javax.swing.JTable posY1S1Table;
    private javax.swing.JTable posY1S2Table;
    private javax.swing.JPanel posY2Panel;
    private javax.swing.JTable posY2S1Table;
    private javax.swing.JTable posY2S2Table;
    private javax.swing.JPanel posY3Panel;
    private javax.swing.JTable posY3S1Table;
    private javax.swing.JTable posY3S2Table;
    private javax.swing.JPanel posY4Panel;
    private javax.swing.JTable posY4S1Table;
    private javax.swing.JTable posY4S2Table;
    private javax.swing.JPanel posY5Panel;
    private javax.swing.JTable posY5S1Table;
    private javax.swing.JTable posY5S2Table;
    private javax.swing.JButton refreshNumCreditsButton;
    private javax.swing.JButton requirementsMetLabel;
    private javax.swing.JMenuItem saveMenuItem;
    private javax.swing.JTabbedPane studentTabbedPane;
    private javax.swing.JMenuItem switchUserMenuItem;
    private javax.swing.JLabel transcriptEditLabel;
    private javax.swing.JPanel transcriptPanel;
    private javax.swing.JLabel transcriptTabLabel;
    private javax.swing.JTabbedPane transcriptTabbedPane;
    private javax.swing.JPanel transcriptY1Panel;
    private javax.swing.JTable transcriptY1S1Table;
    private javax.swing.JTable transcriptY1S2Table;
    private javax.swing.JPanel transcriptY2Panel;
    private javax.swing.JTable transcriptY2S1Table;
    private javax.swing.JTable transcriptY2S2Table;
    private javax.swing.JPanel transcriptY3Panel;
    private javax.swing.JTable transcriptY3S1Table;
    private javax.swing.JTable transcriptY3S2Table;
    private javax.swing.JPanel transcriptY4Panel;
    private javax.swing.JTable transcriptY4S1Table;
    private javax.swing.JTable transcriptY4S2Table;
    private javax.swing.JPanel transcriptY5Panel;
    private javax.swing.JTable transcriptY5S1Table;
    private javax.swing.JTable transcriptY5S2Table;
    private javax.swing.JPopupMenu.Separator userActionSeperator;
    private javax.swing.JMenu userMenu;
    private javax.swing.JMenu userSettingsMenu;
    private javax.swing.JPanel workAreaPanel;
    // End of variables declaration//GEN-END:variables
}
