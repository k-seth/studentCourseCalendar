package user;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

import java.util.Objects;

/**
 *
 * 
 */
public class Semester implements Comparable<Semester>  {

    /**
     * An inner class of Semester that allows for determining if the passed term is a fall or winter semester.
     */
    public enum TERM {
        WINTER,
        FALL;

        /**
         * A static method that will return FALL if the term starts with F, or W. This is useful for doing comparisons.
         * 
         * @param term
         * @return
         */
        public static TERM fromString(String term) {
            switch(term.charAt(0)) {
                case 'F':
                    return FALL;
                case 'W':
                    return WINTER;
                default:
                    throw new IllegalArgumentException();
            }
        }
        
        @Override
        public String toString() {
            return this == FALL ? "F" : "W";
        }
    }
    
    private TERM term;
    private int year;
    
    /**
     * An empty, parameterless constructor.
     */
    private Semester() {     
    }
    
    /**
     * An overloaded constructor that takes a TERM enum value and a year.
     * 
     * @param term
     * @param year
     */
    private Semester(TERM term, int year) {
        this.term = term;
        this.year = year;
    }
    
    /**
     * Creates a new semester object that contains a TERM and year member.
     * 
     * @param semesterString
     * @return 
     */
    public static Semester fromString(String semesterString) {
        try {
            TERM term = TERM.fromString(semesterString);
            int year = Integer.parseInt(semesterString.substring(1));
            return new Semester(term, year);
        } catch(StringIndexOutOfBoundsException | IllegalArgumentException e) {
            return null; //TODO
        }
    }

    /**
     * Returns a TERM representing the term a course was taken in.
     * 
     * @return
     */
    public TERM getTerm() {
        return term;
    }

    /**
     * Returns an int representing the year a course was taken
     * 
     * @return
     */
    public int getYear() {
        return year;
    }
    
    @Override
    public int compareTo(Semester o) {
        if (o == null) {
            //TODO
        }
        int yearComparison = Integer.valueOf(year).compareTo(o.getYear());
        
        if(yearComparison != 0) {
            return yearComparison;
        }
        
        return term.compareTo(o.getTerm());       
    }

    @Override
    public String toString() {
        return term.toString() + year;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 19 * hash + Objects.hashCode(this.term);
        hash = 19 * hash + this.year;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Semester other = (Semester) obj;
        if (this.year != other.year) {
            return false;
        }
        if (this.term != other.term) {
            return false;
        }
        return true;
    }
    
    
}
