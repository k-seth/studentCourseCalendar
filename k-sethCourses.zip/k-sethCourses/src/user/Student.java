package user;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

import exceptions.CourseAlreadyExistsException;
import exceptions.CourseNotFoundException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import univ.CourseCatalog;
import univ.Degree;

/**
 * The Student class allows for the creation and manipulation of a Student.
 * <p>
 * Implements Serializable so that the class object may be written to file by other classes.
 */
public class Student implements Serializable {

    private static final long serialVersionUID = 1L;
    private final HashMap<String, Attempt> transcript;
    private final HashMap<String, String> planOfStudy;
    
    private CourseCatalog catalog;
    
    private String firstName;
    private String lastName;
    private Integer studentNum;
    private String studentMajor;
    
    /**
     * An empty, parameterless constructor.
     */
    public Student() {
        transcript = new HashMap<>();
        planOfStudy = new HashMap<>();
    }
    
    /**
     * A constructor that takes a course catalog.
     * 
     * @param catalog
     */
    public Student(CourseCatalog catalog) {
        this();
        this.catalog = catalog;
    }
    
    /**
     * Constructor that takes in a first name, last name, an Integer, and a course catalog.
     * 
     * @param first
     * @param last
     * @param num
     * @param catalog
     */
    public Student(String first, String last, Integer num, CourseCatalog catalog) {
        this(catalog);
        firstName = first;
        lastName = last;
        studentNum = num;
    }
    
    /**
     * Returns a String representing the full name of the student.
     * 
     * @return
     */
    public String getFullName() {
        return getFirstName() + " " + getLastName();
    }
    
    /**
     * Sets the first name equal to the passed argument.
     * 
     * @param first
     */
    public void setFirstName(String first) {
        firstName = first;
    }
    
    /**
     * Returns a String representing the first name of the student.
     * 
     * @return
     */
    public String getFirstName() {
        return firstName;
    }
    
    /**
     * Sets the last name equal to the passed argument.
     * 
     * @param last
     */
    public void setLastName(String last) {
        lastName = last;
    }
    
    /**
     * Returns a String representing the last name of the student.
     * 
     * @return
     */
    public String getLastName() {
        return lastName;
    }
    
    /**
     * Sets the student major equal to the passed argument.
     * 
     * @param major
     */
    public void setMajor(String major) {
        studentMajor = major;
    }
    
    /**
     * Returns a String representing the student major.
     * 
     * @return
     */
    public String getMajor() {
        return studentMajor;
    }
    
    /**
     * Sets the student number equal to the passed argument.
     * 
     * @param studentNum
     */
    public void setStudentNumber(Integer studentNum) {
        this.studentNum = studentNum;
    }
    
    /**
     * Returns an Integer representing the student's student number.
     * 
     * @return
     */
    public Integer getStudentNumber() {
        return studentNum;
    }
    
    /**
     * Adds a new attempted course to the student transcript.
     * 
     * @param courseCode
     * @param semester
     * @param grade
     * @throws exceptions.CourseAlreadyExistsException
     * @throws exceptions.CourseNotFoundException
     */
    public void addAttempt(String courseCode, String semester, String grade) throws CourseAlreadyExistsException, CourseNotFoundException{
        Attempt attemptedCourse;
        String key = generateKey(courseCode, semester);
        
        if(transcript.containsKey(key)) {
            throw new CourseAlreadyExistsException();
            // Notify the user the attempt already exists
        }
        
        attemptedCourse = new Attempt(grade, semester, catalog.findCourse(courseCode));
        transcript.put(key, attemptedCourse);
    }
    
    /**
     * Returns an anonymous Map representing the transcript HashMap.
     * 
     * @return
     */
    public Map<String, Attempt> getTranscript() {
        return new HashMap<>(transcript);
    }
    
    /**
     * Removes an attempted course from the student transcript.
     * 
     * @param courseCode
     * @param semester
     */
    public void removeAttempt(String courseCode, String semester) {
        String key = generateKey(courseCode, semester);
        
        if(!transcript.containsKey(key)) {
            // Notify user the course and semester do not match anything on record
        } else {
            transcript.remove(key);
        }
    }
    
    /**
     * Adds a new course to the student's plan of study.
     * 
     * @param courseCode
     * @param semester
     * @throws exceptions.CourseAlreadyExistsException
     */
    public void addPlanned(String courseCode, String semester) throws CourseAlreadyExistsException {
        if(planOfStudy.containsKey(courseCode)) {
            throw new CourseAlreadyExistsException();
        }

        planOfStudy.put(courseCode, semester);
    }
    
    /**
     * Returns an anonymous Map representing the planOfStudy HashMap.
     * 
     * @return
     */
    public Map<String, String> getPlanned() {
        return new HashMap<>(planOfStudy);
    }
    
    /**
     * Removes a planned course from the student plan of study.
     * 
     * @param courseCode
     * @param semester
     */
    public void removePlanned(String courseCode, String semester) {
        if(planOfStudy.containsKey(courseCode) && planOfStudy.get(courseCode).equals(semester)) {
            planOfStudy.remove(courseCode);
        }
    }    
    
    /**
     * Returns a string that is the combination of the two supplied arguments.
     * Used to generate a unique key for a map to allow multiple instances of a course.
     * 
     * @param stringOne
     * @param stringTwo
     * @return 
     */
    public String generateKey(String stringOne, String stringTwo) {
        return (stringOne + "_" + stringOne);
    }
    
    @Override
    public String toString() {
        return getFullName() + " (" + getStudentNumber() + ")";
    }
    
    @Override
    public boolean equals(Object o) {
        if(o == null) {
            return false;
        } else if(o instanceof Student){
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + Objects.hashCode(this.firstName);
        hash = 89 * hash + Objects.hashCode(this.lastName);
        hash = 89 * hash + Objects.hashCode(this.studentNum);
        return hash;
    }
}
