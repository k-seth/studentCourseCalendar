package user;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

import java.util.Objects;
import univ.Course;

/**
 * The Attempt class allows for the creation and manipulation of an attempt object.
 * This will allow users to track enrollment information for a course.
 */
public class Attempt {

    private String courseGrade;
    private String courseSemester;
    private Course courseAttempted;
    
    /**
     * A parameterless constructor for initializing an attempt object.
     */
    public Attempt() {
    }

    /**
     * A constructor for initializing an attempt object with initial data.
     * 
     * @param grade
     * @param semester
     * @param theCourse
     */
    public Attempt(String grade, String semester, Course theCourse) {
        courseGrade = grade;
        courseSemester = semester;
        courseAttempted = theCourse;
    }
    
    /**
     * Sets the grade for the course attempted equal to the passed argument.
     * 
     * @param grade
     */
    public void setAttemptGrade(String grade) {
        courseGrade = grade;
    }

    /**
     * Returns a String representing the attempt grade.
     * 
     * @return
     */
    public String getAttemptGrade() {
        return courseGrade;
    }

    /**
     * Sets the semester for the course attempted equal to the passed argument.
     * 
     * @param semester
     */
    public void setSemesterTaken(String semester) {
        courseSemester = semester;
    }

    /**
     * Returns a String representing the semester taken.
     * 
     * @return
     */
    public String getSemesterTaken() {
        return courseSemester;
    }

    /**
     * Sets the course attempted equal to the passed argument.
     * 
     * @param theCourse
     */
    public void setCourseAttempted(Course theCourse) {
        courseAttempted = theCourse;
    }

    /**
     * Returns a Course representing the course attempted.
     * 
     * @return 
     */
    public Course getCourseAttempted() {
        return new Course(courseAttempted);
    }
    
    @Override
    public String toString() {
        return "Attempt{" + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.courseGrade);
        hash = 71 * hash + Objects.hashCode(this.courseSemester);
        hash = 71 * hash + Objects.hashCode(this.courseAttempted);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Attempt other = (Attempt) obj;
        if (!Objects.equals(this.courseGrade, other.courseGrade)) {
            return false;
        }
        if (!Objects.equals(this.courseSemester, other.courseSemester)) {
            return false;
        }
        if (!Objects.equals(this.courseAttempted, other.courseAttempted)) {
            return false;
        }
        return true;
    }
}
