package exceptions;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

/**
 * CourseAlreadyExistsException provides exception handling for cases where the user is attempting to add a course that already exists.
 */
public class CourseAlreadyExistsException extends Exception {

    private static final long serialVersionUID = 1L;

    /**
     * Creates a new instance of <code>CourseAlreadyExistsException</code>
     * without detail message.
     */
    public CourseAlreadyExistsException() {
    }

    /**
     * Constructs an instance of <code>CourseAlreadyExistsException</code> with
     * the specified detail message.
     *
     * @param msg the detail message.
     */
    public CourseAlreadyExistsException(String msg) {
        super(msg);
    }
    
    @Override
    public String toString() {
        return "CourseAlreadyExists";
    }
    
    @Override
    public boolean equals(Object o) {
        if(o == null) {
            //System.out.println("The tested object is null");
            return false;
        } else if(o instanceof CourseAlreadyExistsException){
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }
}
