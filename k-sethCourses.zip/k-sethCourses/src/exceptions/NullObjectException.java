
package exceptions;
/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

/**
 * Defines a NullObjectException, an extension of NPE, that is thrown when an object is passed as null
 */
public class NullObjectException extends NullPointerException {

    private static final long serialVersionUID = 1L;

    /**
     * Creates a new instance of <code>NullListException</code> without detail
     * message.
     */
    public NullObjectException() {
    }

    /**
     * Constructs an instance of <code>NullListException</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public NullObjectException(String msg) {
        super(msg);
    }
    
    @Override
    public String toString() {
        return "NullObject";
    }
    
    @Override
    public boolean equals(Object o) {
        if(o == null) {
            //System.out.println("The tested object is null");
            return false;
        } else if(o instanceof NullObjectException){
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }
}
