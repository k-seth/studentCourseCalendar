
package exceptions;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

/**
 * An exception class that will throw when the user searches for a course that does not exist.
 */
public class CourseNotFoundException extends ClassNotFoundException {

    private static final long serialVersionUID = 1L;

    /**
     * Creates a new instance of <code>CourseNotFoundEception</code> without
     * detail message.
     */
    public CourseNotFoundException() {
        
    }

    /**
     * Constructs an instance of <code>CourseNotFoundEception</code> with the
     * specified detail message.
     *
     * @param msg the detail message.
     */
    public CourseNotFoundException(String msg) {
        super(msg);
    }
    
    @Override
    public String toString() {
        return "CourseNotFound";
    }
    
    @Override
    public boolean equals(Object o) {
        if(o == null) {
            //System.out.println("The tested object is null");
            return false;
        } else if(o instanceof CourseNotFoundException){
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }
}
