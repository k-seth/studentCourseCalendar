package univ;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

import java.util.ArrayList;
import java.util.HashMap;

/**
 * An extension of the root class Degree.
 * Defines multiple members for degree specific requirements.
 * Serializable does not need to be implements as it is inherited from the root.
 */
abstract class HonoursDegree extends Degree {

    private static final long serialVersionUID = 1L;
    /* Constants representing the non-course requirements for a Honours Degree */
    private static final double REQUIRED_CREDITS = 20.00;
    private static final double REQUIRED_CIS_CREDITS = 16;
    private static final double MIN_CISTHREELEVEL_CREDITS = 4.00;
    private static final double MIN_CISFOURLEVEL_CREDITS = 2.00;
    private static final double MIN_AOA_CREDITS = 4.00;
    private static final double MAX_INTRO_CREDITS = 6.00;
    private static final double MIN_AOALEVELTHREE_CREDITS = 1.00;
    
    /**
     * Constructor sets the default title for the Degree 
     */
    public HonoursDegree() {
        super.setDegreeTitle("Bachelor of Computing Honours");
    }
    
    @Override
    public double numberOfCreditsRemaining(ArrayList<Course> allTheCoursesPlannedAndTaken) {
        Credits creditCounter = new Credits(allTheCoursesPlannedAndTaken);
        double credits = REQUIRED_CREDITS - creditCounter.getListCredits();
        if(credits < 0) {
            return 0;
        }
        return credits;
    }

    @Override
    public boolean meetsRequirements(ArrayList<Course> allTheCoursesPlannedAndTaken) {
        boolean met = true;
        double cisCredits = 0;
        double cisThreeLevel = 0;
        double cisFourLevel = 0;
        double aoaCredits = 0;
        double aoaThreeLevel = 0;
        double oneLevel = 0;
        
        HashMap<String, Course> allTheCourses = new HashMap<>();
        
        for (Course listCourse : allTheCoursesPlannedAndTaken) {
            allTheCourses.put(listCourse.getCourseCode(), listCourse);
        }
        
        if(numberOfCreditsRemaining(allTheCoursesPlannedAndTaken) > 0.0) {
            met = false;
        }
        
        if(!super.remainingRequiredCourses(allTheCoursesPlannedAndTaken).isEmpty()) {
            met = false;
        }
        
        /* Since this degree is different than general, it must be done differently */
        
        for(Course course: allTheCourses.values()) {
            if(course.getCourseCode().split("\\*")[0].startsWith("CIS") || course.getCourseCode().equals("MATH*1200") || course.getCourseCode().equals("STAT*2040")) {
                cisCredits += course.getCourseCredit();
                
                if(course.getCourseCode().split("\\*")[1].startsWith("3")) {
                    cisThreeLevel += course.getCourseCredit();
                } else if(course.getCourseCode().split("\\*")[1].startsWith("4")) {
                    if(cisFourLevel >= MIN_CISFOURLEVEL_CREDITS && cisThreeLevel < MIN_CISTHREELEVEL_CREDITS) {
                        cisThreeLevel += course.getCourseCredit();
                    } else {
                        cisFourLevel += course.getCourseCredit();
                    }
                } else if(course.getCourseCode().split("\\*")[1].startsWith("1")) {
                    oneLevel += course.getCourseCredit();
                }
            } else {
                aoaCredits += course.getCourseCredit();
                
                if(course.getCourseCode().split("\\*")[1].startsWith("1")) {
                    oneLevel += course.getCourseCredit();
                } else if(course.getCourseCode().split("\\*")[1].startsWith("3")) {
                    aoaThreeLevel += course.getCourseCredit();
                }
            }
        }

        if(oneLevel > MAX_INTRO_CREDITS) {
            met = false;
        }
        if(cisCredits < REQUIRED_CIS_CREDITS) {
            met = false;
        }
        if(cisThreeLevel < MIN_CISTHREELEVEL_CREDITS) {
            met = false;
        }
        if(cisFourLevel < MIN_CISFOURLEVEL_CREDITS) {
            met = false;
        }
        if(aoaCredits < MIN_AOA_CREDITS) {
            met = false;
        }
        if(aoaThreeLevel < MIN_AOALEVELTHREE_CREDITS) {
            met = false;
        }
        /* All grade handling was removed as this function no longer has access to this information */
        
        return met;
    }
    
    @Override
    public String toString() {
        return "An abstract class presenting a " + getDegreeTitle() + " degree";
    }
    
    @Override
    public boolean equals(Object o) {
        if(o == null) {
            return false;
        } else if(o instanceof HonoursDegree){
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }
}
