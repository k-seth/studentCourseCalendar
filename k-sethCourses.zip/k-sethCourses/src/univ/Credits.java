
package univ;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

import exceptions.CourseNotFoundException;
import exceptions.NullObjectException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;
import user.Attempt;
import user.Semester;
import user.Student;

/**
 * Allows for the creation and manipulation of a Credits object to do credit related calculations.
 * After looking at it, this class could be refactored to be static methods I believe.
 */
public class Credits {

    private HashMap<String, Attempt> attempt;
    private HashMap<String, String> planOfStudy;
    private ArrayList<Course> allCourses;
    
    private CourseCatalog catalog;
    
    /**
     * A parameterless constructor
     */
    public Credits() {    
    }
    
    /**
     * Overloaded constructor that takes a list of planned and completed courses courses 
     * 
     * @param passedList
     */
    public Credits(ArrayList<Course> passedList) {    
        allCourses = passedList;
    }
    
    /**
     * Overloaded constructor that take a map, and casts it to a HashMap.
     * 
     * @param theStudent
     * @param catalog
     */
    public Credits(Student theStudent, CourseCatalog catalog) throws NullObjectException { 
        if(theStudent == null || catalog == null) {
            throw new NullObjectException();
        }
        this.attempt = (HashMap<String, Attempt>) theStudent.getTranscript();
        this.planOfStudy = (HashMap<String, String>) theStudent.getPlanned();
        this.catalog = catalog;
    }
    
    /**
     * Returns a double representing the number of credits currently planned in the plan of study.
     * 
     * @return
     */
    public double getPlannedCredits() {
        double credits = 0;
        
        for(String key : planOfStudy.keySet()) {
            try {
                credits += catalog.findCourse(key).getCourseCredit();
            } catch (CourseNotFoundException ex) {
                // This should not be tripped, as a student can't add a course that doesn't exist
            }
        }
        
        return credits;
    }
    
    /**
     * Returns a double representing the number of credits currently successfully earned in the student transcript.
     * 
     * @return
     */
    public double getTranscriptCredits() {
        double credits = 0;
        
        for(String key : attempt.keySet()) {
            try {
                if(attempt.get(key).getAttemptGrade().equals("P") || Double.parseDouble(attempt.get(key).getAttemptGrade()) >= 50) {
                    credits += attempt.get(key).getCourseAttempted().getCourseCredit();
                }
            } catch (NumberFormatException e) {
                // No need to do anything, because that means the grade is "INC", "F", or "MNR", meaning the student did not earn the credit
            }
        }
        
        return credits;
    }
        
    /**
     * Returns a double representing all credits in the students plan and transcript.
     * 
     * @return
     */
    public double getListCredits() {
        double credits = 0;
        
        for(Course course : allCourses) {
            credits += course.getCourseCredit();
        }
        
        return credits;
    }
    
    /**
     * Returns a double representing the total GPA of all completed courses with a grade.
     * 
     * @return
     */
    public double calculateGPA() {
        double gpa = 0;
        int coursesCounted = 0;
        
        for(String key : attempt.keySet()) {
            try {
                gpa += Double.parseDouble(attempt.get(key).getAttemptGrade());
                coursesCounted ++;
            } catch (NumberFormatException e) {
            }
        }
        
        /* Catch a divide by zero issuse */
        if(coursesCounted == 0) {
            return 0;
        }
        gpa /= coursesCounted;
        
        return gpa;
    }
    
    /**
     * Returns a double representing the total GPA for all completed CIS courses.
     * 
     * @return
     */
    public double calculateCISGPA() {
        double gpa = 0;
        int coursesCounted = 0;
        
        for(String key : attempt.keySet()) {
            try {
                if(attempt.get(key).getCourseAttempted().getCourseCode().split("\\*")[0].equals("CIS")) {
                    gpa += Double.parseDouble(attempt.get(key).getAttemptGrade());
                    coursesCounted ++;
                }
            } catch (NumberFormatException e) {
                gpa += 0;
            }
        }
        if(coursesCounted == 0) {
            return 0;
        }
        gpa /= coursesCounted;
        
        return gpa;
    }
    
    /**
     * Returns a double representing the total GPA of the last 10 completed courses in the transcript.
     * 
     * @return
     */
    public double calculateLastTenGPA() {
        double gpa = 0, credits = 0;
        int coursesCounted = 0;
        
        /* 
         * Use stream to create a list of attempts which are sorted in reverse order of being taken (Most recent are at the beginning)
         */
        List<Attempt> termCourses;
        termCourses = attempt.values().stream()
                .sorted((f1,f2) -> Semester.fromString(f2.getSemesterTaken()).compareTo(Semester.fromString(f1.getSemesterTaken())))
                .collect(Collectors.toList());
        
        for(int i = 0; i < termCourses.size(); i++) {
            if(credits >= 10) {
                break;
            }
            try {
                gpa += Double.parseDouble(termCourses.get(i).getAttemptGrade());
                coursesCounted++;
                credits += termCourses.get(i).getCourseAttempted().getCourseCredit();
            } catch(NumberFormatException ex) {
                // If this is tripped, then it is not a number grade. So do not factor it into grade, but continue searching
            }
        }
        
        /* This will prevent a divide by zero issue */
        if(coursesCounted == 0) {
            return 0;
        }
        gpa /= coursesCounted;
        
        return gpa;
    }

    @Override
    public String toString() {
        return "Credits{" + "attempt=" + attempt + ", planOfStudy=" + planOfStudy + ", allCourses=" + allCourses + ", catalog=" + catalog + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 71 * hash + Objects.hashCode(this.attempt);
        hash = 71 * hash + Objects.hashCode(this.planOfStudy);
        hash = 71 * hash + Objects.hashCode(this.allCourses);
        hash = 71 * hash + Objects.hashCode(this.catalog);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Credits other = (Credits) obj;
        if (!Objects.equals(this.attempt, other.attempt)) {
            return false;
        }
        if (!Objects.equals(this.planOfStudy, other.planOfStudy)) {
            return false;
        }
        if (!Objects.equals(this.allCourses, other.allCourses)) {
            return false;
        }
        if (!Objects.equals(this.catalog, other.catalog)) {
            return false;
        }
        return true;
    }
    
    
}
