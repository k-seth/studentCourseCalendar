package univ;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

/**
 * An extension of GeneralDegree.
 * A concrete class which allows for an object of a degree to be created.
 */
public class BCG extends GeneralDegree {

    private static final long serialVersionUID = 1L;
    
    /**
     * An empty, parameterless constructor.
     */
    public BCG() {
    }
    
    @Override
    public String toString() {
        return "BC:G";
    }
    
    @Override
    public boolean equals(Object o) {
        if(o == null) {
            //System.out.println("The tested object is null");
            return false;
        } else if(o instanceof BCG){
            //System.out.println("The tested object is an instance of BCG");
            return true;
        } else {
            //System.out.println("The tested object is not a BCG");
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }
}
