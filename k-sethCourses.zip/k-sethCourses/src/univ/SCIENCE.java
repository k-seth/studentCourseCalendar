package univ;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

/**
 * The SCIENCE enum gives a list of the starting part of science course codes.
 * This is borrowed from the lecture slides, so thanks Judi.
 */
public enum SCIENCE {
    BIOL, MATH, ECON, BIOM, ECOL, FOOD, PHYS, CHEM, ZOO, STAT
}
