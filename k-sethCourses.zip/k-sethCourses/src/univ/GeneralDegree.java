package univ;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

import java.util.ArrayList;
import java.util.HashMap;

/**
 * An extension of the root class Degree.
 * Defines multiple members for degree specific requirements.
 * Serializable does not need to be implements as it is inherited from the root.
 */
abstract class GeneralDegree extends Degree {

    private static final long serialVersionUID = 1L;
    /* Constants representing the non-course requirements for a General Degree */
    /* Requires that satisfy some of these conditions are automatically accounted for */
    private static final double REQUIRED_CREDITS = 15.00;
    private static final double MAX_CIS_CREDITS = 6.75;
    private static final double MIN_CISLEVELTHREE_CREDITS = 1.00;
    private static final double MIN_CISLEVELTWO_CREDITS = 0.50;
    private static final double MAX_INTRO_CREDITS = 4.00;
    private static final double MIN_LEVELTHREE_CREDITS = 3.50;
    private static final double SCIENCE_CREDITS = 2.00;
    private static final double ARTS_CREDITS = 2.00;
    
    /**
     * Constructor sets the default title for the Degree 
     */
    public GeneralDegree() {
        super.setDegreeTitle("Bachelor of Computing General");
    }
    
    @Override
    public double numberOfCreditsRemaining(ArrayList<Course> allTheCoursesPlannedAndTaken) {
        Credits creditCounter = new Credits(allTheCoursesPlannedAndTaken);
        return REQUIRED_CREDITS - creditCounter.getListCredits();
    }
    
    @Override
    public boolean meetsRequirements(ArrayList<Course> allTheCoursesPlannedAndTaken) {
        boolean met = true;
        double cisCredits = 0;
        double cisThreeLevel = 0;
        double cisTwoLevel = 0;
        double threeLevel = 0;
        double oneLevel = 0;
        double scienceCredits = 0;
        double artsCredits = 0;
        
        HashMap<String, Course> allTheExtraCourses = new HashMap<>();
        boolean isEnum;
                
        for (Course listCourse : allTheCoursesPlannedAndTaken) {
            allTheExtraCourses.put(listCourse.getCourseCode(), listCourse);
        }
        
        SCIENCE sciCredit = null;
        
        /* Rather than simply check and move on, I designed this to provide accurate feedback about what needs to still be done to be able to meet the requirements */
        /* As such, the user is given feedback about any or all cases they failed. It will check all before exiting */
        /* Edit to above comments ---- */
        /* That was the original intent, however, now it does not, as modelling this into the GUI would be a pain. */
        if(numberOfCreditsRemaining(allTheCoursesPlannedAndTaken) > 0.0) {
            met = false;
        }
        
        if(!super.remainingRequiredCourses(allTheCoursesPlannedAndTaken).isEmpty()) {
            met = false;
        }
        
        /* This removes the course required courses from the plan of study, since they have already been checked above */
        for (Course course : super.getRequiredCourses()) {
            if(allTheExtraCourses.containsKey(course.getCourseCode())) {
                allTheExtraCourses.remove(course.getCourseCode());
            }
        }
        
        for(Course course: allTheExtraCourses.values()) {
            isEnum = false;
            if(course.getCourseCode().split("\\*")[0].startsWith("CIS")) {
                cisCredits += course.getCourseCredit();
                if(course.getCourseCode().split("\\*")[1].startsWith("2")) {
                    cisTwoLevel += course.getCourseCredit();
                }
                if((course.getCourseCode().split("\\*")[1].startsWith("3") || course.getCourseCode().split("\\*")[1].startsWith("4"))) {
                    if(cisThreeLevel >= MIN_CISLEVELTHREE_CREDITS && cisTwoLevel < MIN_CISLEVELTWO_CREDITS) {
                        cisTwoLevel += course.getCourseCredit();
                    } else {
                        cisThreeLevel += course.getCourseCredit();
                    }
                }
            } else {
                try {
                    sciCredit = SCIENCE.valueOf(course.getCourseCode().split("\\*")[0]);
                    isEnum = true;
                } catch(IllegalArgumentException e) {
                    /* Since I don't want to do anything with this, catch and move on */
                }

                if(isEnum == true) {
                    if(course.getCourseCode().split("\\*")[0].equals(sciCredit.toString())) { //SCIENCE.valueOf(course.getCourseCode().split("\\*")[0]).toString()
                        scienceCredits += course.getCourseCredit();
                        if(course.getCourseCode().split("\\*")[0].startsWith("STAT") && (course.getCourseCode().split("\\*")[1].startsWith("2") || course.getCourseCode().split("\\*")[1].startsWith("3"))) {
                        cisTwoLevel += course.getCourseCredit();
                        }
                    }
                } else {
                    artsCredits += course.getCourseCredit();
                }
            }

            if(course.getCourseCode().split("\\*")[1].startsWith("1")) {
                oneLevel += course.getCourseCredit();
            } else if(course.getCourseCode().split("\\*")[1].startsWith("3")) {
                threeLevel += course.getCourseCredit();
            }
        }
        
        if(cisCredits > MAX_CIS_CREDITS) {
            met = false;
        }
        if(oneLevel > MAX_INTRO_CREDITS) {
            met = false;
        }
        if(cisTwoLevel < MIN_CISLEVELTWO_CREDITS) {
            met = false;
        }
        if(cisThreeLevel < MIN_CISLEVELTHREE_CREDITS) {
            met = false;
        }
        if(threeLevel < MIN_LEVELTHREE_CREDITS) {
            met = false;
        }
        if(scienceCredits < SCIENCE_CREDITS) {
            met = false;
        }
        if(artsCredits < ARTS_CREDITS) {
            met = false;
        }
        return met;
    }
    
    @Override
    public String toString() {
        return "An abstract class presenting a " + getDegreeTitle()  + " degree";
    }
    
    @Override
    public boolean equals(Object o) {
        if(o == null) {
            return false;
        } else if(o instanceof GeneralDegree){
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }
}
