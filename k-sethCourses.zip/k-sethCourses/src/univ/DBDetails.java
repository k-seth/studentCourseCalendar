package univ;

public class DBDetails
{
    public static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  


    /** Change cis2430 in this string to be your login name.  Leave the rest of the string intact */
    // UoG
     public static final String DB_URL = "jdbc:mysql://dursley.socs.uoguelph.ca:3306/skuipers?useLegacyDatetimeCode=false&serverTimezone=America/New_York";
    // Home
//    public static final String DB_URL = "jdbc:mysql://vm-db-server:3306/skuipers?useLegacyDatetimeCode=false&serverTimezone=America/New_York";

    /** Change the username to be your own login name */
    public static final String username = "skuipers";

    /** Change the password to be your student number.  DO NOT USE YOUR NORMAL PASSWORD*/
    public static final String password = "1004947";

}
