/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package univ;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import user.Semester;

/**
 *
 * @author Seth
 */
public class TestClass {
    public static void main(String[] args) {
        String[] test = {"F19", "W18", "F17", "F18", "W19"};
        //String[] test = {"F19", "F20", "F17", "F18", "F21"};
        List<String> test2 = new ArrayList<>(Arrays.asList(test));
        
        System.out.println(
                test2.stream()
                        .map(S->Semester.fromString(S))
                        .sorted()
                        .map(S->S.toString())
                        .collect(Collectors.joining(",")));
    }
    
    /**
     * A helper test function.
     * 
     * @param filename
     * @return
     */
    public static HashMap<String, Course> initializeCatalog(String filename) {
        HashMap<String, Course> courseCatalog = new HashMap<>();
        ArrayList<Course> reqCourses;
        String readLine;
        String[] splitString;
        String[] req;
        
        BufferedReader buffer;
        Course tempCourse;
        
        try {
            buffer = new BufferedReader(new FileReader(new File(filename)));
            /* Only override what exists if a file can be found */
            while((readLine = buffer.readLine()) != (null)) {
                splitString = readLine.trim().split(",");
                if(splitString[0].length() != 0 && splitString[1].length() != 0 && splitString[2].length() != 0) {
                    reqCourses = new ArrayList<>();
                    if(splitString.length > 4) {
                        req = splitString[4].split(":");

                        /* Add any prerequisite courses first */
                        for(int i = 0; i < req.length; i++) {
                            /* If a course does not exist in the catalog, make sure to create a new course with just a course code */
                            if(!courseCatalog.containsKey(req[i])) {
                                tempCourse = new Course();
                                tempCourse.setCourseCode(req[i]);
                                addCourse(tempCourse, courseCatalog);
                            }
                            reqCourses.add(courseCatalog.get(req[i]));
                        }
                    }

                    /* This is for adding the course */
                    /* Check if the course already exists (This means it will have been added as prerequisite course)*/
                    /* If the course already exists, make sure it is not already filled in. If it is, ignore the new entry and move on */
                    if(courseCatalog.containsKey(splitString[0]) && !splitString[2].equals(courseCatalog.get(splitString[0]).getCourseTitle())) {
                        courseCatalog.get(splitString[0]).setCourseCredit(Double.parseDouble(splitString[1]));
                        courseCatalog.get(splitString[0]).setCourseTitle(splitString[2]);
                        courseCatalog.get(splitString[0]).setSemesterOffered(splitString[3]);
                        courseCatalog.get(splitString[0]).setPrerequisites(reqCourses);
                    } else if(!courseCatalog.containsKey(splitString[0])) {
                        addCourse(new Course(splitString[0], Double.parseDouble(splitString[1]), splitString[2], splitString[3], reqCourses), courseCatalog);
                    } 
                }
            }

            buffer.close();
            //System.out.println("Loaded all available courses\n");
        } catch (FileNotFoundException e) {
            //System.err.format("No specified file (%s) found in CourseCatalog.\n", filename);
            System.err.println(e.getMessage());
        } catch (IOException e) {
            //System.err.println("IO error with buffer in CourseCatalog");
            System.err.println(e.getMessage());
        }
        return courseCatalog;
    }
    
    /**
     * A helper test function.
     * 
     * @param catalog
     * @return
     */
    public static Degree setBCGRequiredCourses(CourseCatalog catalog) {
        BufferedReader fileReader = null;
        String temp;
        String[] tempString;;
        BCG bcgObject = new BCG();
        
        try {    
            try {
                fileReader = new BufferedReader(new FileReader("BCG.txt"));
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TestClass.class.getName()).log(Level.SEVERE, null, ex);
            }
            ArrayList<String> requiredCourses = new ArrayList<>();
            
            /* When reading from the file, trim any excess whitespace to account for newlines */
            while(((temp = fileReader.readLine())) != null) {
                tempString = temp.trim().split(",");
                for(int i = 1; i < tempString.length; i++) {
                    requiredCourses.add(tempString[i]);
                }
                
                bcgObject = new BCG();
                bcgObject.updateCourseCatalog(catalog);
                bcgObject.setRequiredCourses(requiredCourses);
            }
            fileReader.close();
            return bcgObject;
        } catch (IOException ex) {
            Logger.getLogger(TestClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    /**
     * A helper test function.
     * 
     * @return
     */
    public static Degree setCSRequiredCourses(CourseCatalog catalog) {
        BufferedReader fileReader = null;
        String temp;
        String[] tempString;
        CS csObject = new CS();
        
        try {    
            try {
                fileReader = new BufferedReader(new FileReader("CS.txt"));
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TestClass.class.getName()).log(Level.SEVERE, null, ex);
            }
            ArrayList<String> requiredCourses = new ArrayList<>();
            
            /* When reading from the file, trim any excess whitespace to account for newlines */
            while(((temp = fileReader.readLine())) != null) {
                tempString = temp.trim().split(",");
                for(int i = 1; i < tempString.length; i++) {
                    requiredCourses.add(tempString[i]);
                }
                
                /* Create the objects and pass in the course catalog and set required courses */
                csObject = new CS();
                csObject.updateCourseCatalog(catalog);
                csObject.setRequiredCourses(requiredCourses);
            }
            fileReader.close();
            return csObject;
            
        } catch (IOException ex) {
            Logger.getLogger(TestClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    /**
     * A helper test function.
     * 
     * @return
     */
    public static Degree setSENGRequiredCourses(CourseCatalog catalog) {
        BufferedReader fileReader = null;
        String temp;
        String[] tempString;
        
        SEng sengObject = new SEng();
        
        try {    
            try {
                fileReader = new BufferedReader(new FileReader("SENG.txt"));
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TestClass.class.getName()).log(Level.SEVERE, null, ex);
            }
            ArrayList<String> requiredCourses = new ArrayList<>();
            
            /* When reading from the file, trim any excess whitespace to account for newlines */
            while(((temp = fileReader.readLine())) != null) {
                tempString = temp.trim().split(",");
                for(int i = 1; i < tempString.length; i++) {
                    requiredCourses.add(tempString[i]);
                }
                
                /* Create the objects and pass in the course catalog and set required courses */
                sengObject = new SEng();
                sengObject.updateCourseCatalog(catalog);
                sengObject.setRequiredCourses(requiredCourses);
            }
            fileReader.close();
            return sengObject;
        } catch (IOException ex) {
            Logger.getLogger(TestClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    /**
     * Adds a new course to the courseCatalog.
     * If a course with the course code already exists, no action will be taken.
     * 
     * @param toAdd
     * @param courseCatalog
     */
    public static void addCourse(Course toAdd, HashMap<String, Course> courseCatalog) {
        if(toAdd == null) {
            System.out.println("Unable to add empty course");
            return;
        }
        /*if(toAdd.getCourseCode().length() == 0 || toAdd.getCourseTitle().length() == 0) {
            return;
        }*/
        /* Do I need to even have this condition? */
        if(!courseCatalog.containsKey(toAdd.getCourseCode())) {
            courseCatalog.put(toAdd.getCourseCode(), toAdd);
        }
    }
}
