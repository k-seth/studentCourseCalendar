package univ;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

import exceptions.CourseAlreadyExistsException;
import exceptions.CourseNotFoundException;
import java.io.Serializable;
import java.util.HashMap;

/**
 * The CourseCatalog class allows for the creation and manipulation of a catalog of courses.
 * Expects to read from a CSV with specific formatting.
 * <p>
 * Implements Serializable to allow writing of the class object to file.
 */
public class CourseCatalog implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private final HashMap<String, Course> courseCatalog;
    
    /**
     * A constructor which creates a new HashMap.
     */
    public CourseCatalog() {
        courseCatalog = new HashMap<>();
    }
    
    /**
     * An overloaded constructor which creates a new HashMap with the passed Map.
     * 
     * @param courseCatalog
     */
    public CourseCatalog(HashMap<String, Course> courseCatalog) {
        this.courseCatalog = courseCatalog;
    }
    
    /**
     * Adds a new course to the courseCatalog.
     * If a course with the course code already exists, no action will be taken.
     * 
     * @param toAdd
     * @throws exceptions.CourseAlreadyExistsException
     */
    protected void addCourse(Course toAdd) throws CourseAlreadyExistsException {
        if(toAdd == null) {
            return;
        }
        if(!courseCatalog.containsKey(toAdd.getCourseCode())) {
            courseCatalog.put(toAdd.getCourseCode(), toAdd);
        } else {
            throw new CourseAlreadyExistsException();
        }
    }
    
    /**
     * Attempts to find the original course, and updates it with the new one.
     * 
     * @param newInfo
     * @param original
     * @throws exceptions.CourseNotFoundException
     */
    protected void updateCourse(Course newInfo, Course original) throws CourseNotFoundException {
        if(courseCatalog.containsKey(original.getCourseCode())) {
            courseCatalog.replace(original.getCourseCode(), original, newInfo);
        } else {
            throw new CourseNotFoundException();
        }
    }
    
    /**
     * Removes a course from the courseCatalog.
     * If the course code is not found in the map, no action will be taken.
     * 
     * @param toRemove
     */
    protected void removeCourse(Course toRemove) {
        if(courseCatalog.containsKey(toRemove.getCourseCode())) {
            courseCatalog.remove(toRemove.getCourseCode(), toRemove);
        }
    }
    
    /**
     * Returns a course from the courseCatalog map.
     * A CourseNotFoundException is thrown if the requested course does not exist in the catalog.
     * Otherwise, an anonymous Course is returned.
     * 
     * @param courseCode
     * @return
     * @throws exceptions.CourseNotFoundException
     */
    public Course findCourse(String courseCode) throws CourseNotFoundException {
        if(!courseCatalog.containsKey(courseCode)) {
            throw new CourseNotFoundException();
        }
        return new Course(courseCatalog.get(courseCode));
    }
    
    @Override
    public String toString() {
        return "Course Catalog Object";
    }
    
    @Override
    public boolean equals(Object o) {
        if(o == null) {
            return false;
        } else if(o instanceof CourseCatalog){
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 5;
        return hash;
    }
}
