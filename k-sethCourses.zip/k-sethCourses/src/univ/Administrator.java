package univ;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

import exceptions.CourseAlreadyExistsException;
import exceptions.CourseNotFoundException;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 * A GUI to give administrator functionality to the program. Database can be edited.
 */
public class Administrator extends javax.swing.JFrame {

    /**
     * An inner class to help with tracking table info deletion.
     * Implements KeyListener to allow a KeyEvent to be tracked and used.
     */
    private class deleteFromCatalog implements KeyListener {
        /**
         * Removes a course from the course catalog, and clears the entry from the table.
         * 
         * @param e
         */
        public void delete(KeyEvent e) {
           JTable table = (JTable) e.getComponent();
           DefaultTableModel model = (DefaultTableModel) table.getModel();
        
            /* This if checks to make sure the user is pressed shift, and as well as the delete key. Purely defensive */
            if(e.getKeyCode() == KeyEvent.VK_DELETE && (e.getModifiers() & ActionEvent.SHIFT_MASK) == ActionEvent.SHIFT_MASK) {
                try {
                    catalog.removeCourse(catalog.findCourse(model.getValueAt(table.getSelectedRow(), 0).toString()));
                    
                    model.addRow(new String[3]);
                    model.removeRow(table.getSelectedRow());
                    clearCourseInfo();
                    searchedCourse = null;
                } catch(ArrayIndexOutOfBoundsException ex) {
                    // Do nothing
                } catch (CourseNotFoundException ex) {
                    JOptionPane.showMessageDialog(new JFrame(), "Course could not be removed", "Error", 2);
                }
            } 
        }

        @Override
        public void keyTyped(KeyEvent e) {
        }

        @Override
        public void keyPressed(KeyEvent e) {
            if(e.getKeyCode() == KeyEvent.VK_DELETE && (e.getModifiers() & ActionEvent.SHIFT_MASK) == ActionEvent.SHIFT_MASK) {
                delete(e);
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {
        }
    }
    
    /**
     * An inner class to help with tracking table info deletion.
     * Implements KeyListener to allow a KeyEvent to be tracked and used.
     */
    private class deleteDegree implements KeyListener {
        /**
         * Removes a course from the transcript, and clears the entry from the table.
         * 
         * @param e
         */
        public void delete(KeyEvent e) {
           JTable table = (JTable) e.getComponent();
           DefaultTableModel model = (DefaultTableModel) table.getModel();
        
            /* This if checks to make sure the user is pressing shift, and as well as the delete key */
            if(e.getKeyCode() == KeyEvent.VK_DELETE && (e.getModifiers() & ActionEvent.SHIFT_MASK) == ActionEvent.SHIFT_MASK) {
                try {
                    String degree = model.getValueAt(table.getSelectedRow(), 0).toString();
                    String major = model.getValueAt(table.getSelectedRow(), 1).toString();
                    degree = degree + ":" + major;
                    
                    model.addRow(new String[2]);
                    model.removeRow(table.getSelectedRow());
                    
                    if(degreeList.contains(degree)) {
                        degreeList.remove(degree);
                    }
                } catch(ArrayIndexOutOfBoundsException ex) {
                    // Do nothing
                }   
            } 
        }

        @Override
        public void keyTyped(KeyEvent e) {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }

        @Override
        public void keyPressed(KeyEvent e) {
            if(e.getKeyCode() == KeyEvent.VK_DELETE && (e.getModifiers() & ActionEvent.SHIFT_MASK) == ActionEvent.SHIFT_MASK) {
                delete(e);
            } else if(e.getKeyCode() == KeyEvent.VK_ENTER) {
                //update(e);
            }
        }

        @Override
        public void keyReleased(KeyEvent e) {
            //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        }
    }
    
    private static final long serialVersionUID = 1L;
    
    private static final String HINT_TEXT = "Enter Course Code";
    private static final String HINT_TEXT2 = "Enter Degree Title";
    
    private CourseCatalog catalog;
    private Course searchedCourse;
    private ArrayList<String> degreeList;

    /**
     * Creates new form administrator
     */
    public Administrator() {
        degreeList = new ArrayList<>();
        degreeList.add(new CS().toString());
        degreeList.add(new SEng().toString());
        degreeList.add(new BCG().toString());
        initComponents();
    }

    public Administrator(CourseCatalog catalog) {
        this();
        this.catalog = catalog;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        degreePanel = new javax.swing.JPanel();
        degreeEditLabel = new javax.swing.JLabel();
        degreeSearchLabel = new javax.swing.JLabel();
        degreeSearchTextField = new javax.swing.JTextField();
        clearDegreeTextButton = new javax.swing.JButton();
        degreeTableLabel = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        degreeInfoTable = new javax.swing.JTable();
        degreeChangePanel = new javax.swing.JPanel();
        addDegreeButton = new javax.swing.JButton();
        updateDegreeButton = new javax.swing.JButton();
        coursePanel = new javax.swing.JPanel();
        courseEditLabel = new javax.swing.JLabel();
        courseSearchLabel = new javax.swing.JLabel();
        courseSearchTextField = new javax.swing.JTextField();
        clearAreaButton = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        coursePrereqInfoTable = new javax.swing.JTable();
        courseTableLabel = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        courseInfoTable = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        updateCourseButton = new javax.swing.JButton();
        addCourseButton = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        SeperatorPanel = new javax.swing.JPanel();
        seperator2Panel = new javax.swing.JPanel();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        exitMenuItem = new javax.swing.JMenuItem();
        helpMenu = new javax.swing.JMenu();
        helpMenuItem = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Administrator Terminal");
        setMinimumSize(new java.awt.Dimension(952, 490));
        setResizable(false);

        degreePanel.setBackground(new java.awt.Color(204, 0, 0));
        degreePanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 51), new java.awt.Color(255, 153, 51)));
        degreePanel.setForeground(new java.awt.Color(255, 255, 255));
        degreePanel.setPreferredSize(new java.awt.Dimension(450, 467));

        degreeEditLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        degreeEditLabel.setForeground(new java.awt.Color(255, 255, 255));
        degreeEditLabel.setText("Degree Editing");

        degreeSearchLabel.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        degreeSearchLabel.setForeground(new java.awt.Color(255, 255, 255));
        degreeSearchLabel.setText("Search Database: ");

        degreeSearchTextField.setText(HINT_TEXT2);
        degreeSearchTextField.setToolTipText("Search for a degree (Example: BC for Bachelor of Computing, BCH for Honours");
        degreeSearchTextField.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 51), new java.awt.Color(255, 153, 51)));
        degreeSearchTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                degreeSearchTextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                degreeSearchTextFieldFocusLost(evt);
            }
        });
        degreeSearchTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                degreeSearchTextFieldKeyPressed(evt);
            }
        });

        clearDegreeTextButton.setText("Clear");
        clearDegreeTextButton.setToolTipText("Clears search bar and all displayed degree information");
        clearDegreeTextButton.setAlignmentX(CENTER_ALIGNMENT);
        clearDegreeTextButton.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        clearDegreeTextButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearDegreeTextButtonActionPerformed(evt);
            }
        });

        degreeTableLabel.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        degreeTableLabel.setForeground(new java.awt.Color(255, 255, 255));
        degreeTableLabel.setText("All columns can be edited");

        degreeInfoTable.addKeyListener(new deleteDegree());
        degreeInfoTable.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 51), new java.awt.Color(255, 153, 51)));
        degreeInfoTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null},
                {null, null},
                {null, null},
                {null, null},
                {null, null}
            },
            new String [] {
                "Degree", "Major"
            }
        ));
        degreeInfoTable.setToolTipText("Use shift+del to remove the degree at the selected row from the database");
        degreeInfoTable.getTableHeader().setResizingAllowed(false);
        degreeInfoTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane4.setViewportView(degreeInfoTable);
        if (degreeInfoTable.getColumnModel().getColumnCount() > 0) {
            degreeInfoTable.getColumnModel().getColumn(0).setResizable(false);
            degreeInfoTable.getColumnModel().getColumn(1).setResizable(false);
        }

        degreeChangePanel.setBackground(new java.awt.Color(204, 0, 0));
        degreeChangePanel.setPreferredSize(new java.awt.Dimension(105, 46));
        degreeChangePanel.setLayout(new java.awt.BorderLayout());

        addDegreeButton.setText("Add Degree");
        addDegreeButton.setToolTipText("Adds a new degree. Use the 'Clear' button before adding new information");
        addDegreeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addDegreeButtonActionPerformed(evt);
            }
        });
        degreeChangePanel.add(addDegreeButton, java.awt.BorderLayout.CENTER);

        updateDegreeButton.setText("Update Degree");
        updateDegreeButton.setToolTipText("Updates the searched degree if all information is valid");
        updateDegreeButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateDegreeButtonActionPerformed(evt);
            }
        });
        degreeChangePanel.add(updateDegreeButton, java.awt.BorderLayout.PAGE_END);

        javax.swing.GroupLayout degreePanelLayout = new javax.swing.GroupLayout(degreePanel);
        degreePanel.setLayout(degreePanelLayout);
        degreePanelLayout.setHorizontalGroup(
            degreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(degreePanelLayout.createSequentialGroup()
                .addGroup(degreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(degreePanelLayout.createSequentialGroup()
                        .addGap(188, 188, 188)
                        .addComponent(degreeEditLabel))
                    .addGroup(degreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(degreeChangePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, degreePanelLayout.createSequentialGroup()
                            .addGap(151, 151, 151)
                            .addComponent(degreeTableLabel)))
                    .addGroup(degreePanelLayout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addGroup(degreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(degreePanelLayout.createSequentialGroup()
                                .addComponent(degreeSearchLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(degreeSearchTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(clearDegreeTextButton)))))
                .addContainerGap(73, Short.MAX_VALUE))
        );
        degreePanelLayout.setVerticalGroup(
            degreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(degreePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(degreeEditLabel)
                .addGap(29, 29, 29)
                .addGroup(degreePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(degreeSearchTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clearDegreeTextButton)
                    .addComponent(degreeSearchLabel))
                .addGap(46, 46, 46)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(degreeTableLabel)
                .addGap(20, 20, 20)
                .addComponent(degreeChangePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(129, Short.MAX_VALUE))
        );

        coursePanel.setBackground(new java.awt.Color(204, 0, 0));
        coursePanel.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 51), new java.awt.Color(255, 153, 51)));
        coursePanel.setPreferredSize(new java.awt.Dimension(450, 4));

        courseEditLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        courseEditLabel.setForeground(new java.awt.Color(255, 255, 255));
        courseEditLabel.setText("Course Editing");

        courseSearchLabel.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        courseSearchLabel.setForeground(new java.awt.Color(255, 255, 255));
        courseSearchLabel.setText("Search Database: ");

        courseSearchTextField.setText(HINT_TEXT);
        courseSearchTextField.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 51), new java.awt.Color(255, 153, 51)));
        courseSearchTextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                courseSearchTextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                courseSearchTextFieldFocusLost(evt);
            }
        });
        courseSearchTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                courseSearchTextFieldKeyPressed(evt);
            }
        });

        clearAreaButton.setText("Clear");
        clearAreaButton.setToolTipText("Clears search bar and all displayed course information");
        clearAreaButton.setAlignmentX(CENTER_ALIGNMENT);
        clearAreaButton.setHorizontalAlignment(javax.swing.SwingConstants.TRAILING);
        clearAreaButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearAreaButtonActionPerformed(evt);
            }
        });

        coursePrereqInfoTable.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 51), new java.awt.Color(255, 153, 51)));
        coursePrereqInfoTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "Course Code"
            }
        ));
        coursePrereqInfoTable.setToolTipText("Use shift+del to remove the course at the selected row from the database");
        coursePrereqInfoTable.setColumnSelectionAllowed(true);
        coursePrereqInfoTable.getTableHeader().setResizingAllowed(false);
        coursePrereqInfoTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(coursePrereqInfoTable);
        coursePrereqInfoTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (coursePrereqInfoTable.getColumnModel().getColumnCount() > 0) {
            coursePrereqInfoTable.getColumnModel().getColumn(0).setResizable(false);
        }

        courseTableLabel.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        courseTableLabel.setForeground(new java.awt.Color(255, 255, 255));
        courseTableLabel.setText("All columns can be edited");

        courseInfoTable.addKeyListener(new deleteFromCatalog());
        courseInfoTable.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 0), new java.awt.Color(255, 153, 51), new java.awt.Color(255, 153, 51)));
        courseInfoTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null}
            },
            new String [] {
                "Course Code", "Semester Offered", "Credit Value"
            }
        ));
        courseInfoTable.setToolTipText("Use shift+del to remove the course at the selected row from the database");
        courseInfoTable.getTableHeader().setResizingAllowed(false);
        courseInfoTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane3.setViewportView(courseInfoTable);
        courseInfoTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (courseInfoTable.getColumnModel().getColumnCount() > 0) {
            courseInfoTable.getColumnModel().getColumn(0).setResizable(false);
            courseInfoTable.getColumnModel().getColumn(1).setResizable(false);
            courseInfoTable.getColumnModel().getColumn(2).setResizable(false);
        }

        jPanel2.setBackground(new java.awt.Color(204, 0, 0));
        jPanel2.setLayout(new java.awt.BorderLayout());

        updateCourseButton.setVisible(false);
        updateCourseButton.setText("Update Course");
        updateCourseButton.setToolTipText("Updates the course that was searched if all information is valid. NOTE: Changes to course code will not happen. To change this information, you must delete the course and re-add it");
        updateCourseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateCourseButtonActionPerformed(evt);
            }
        });
        jPanel2.add(updateCourseButton, java.awt.BorderLayout.PAGE_END);

        addCourseButton.setText("Add Course");
        addCourseButton.setToolTipText("Adds a new course if all information is valid. Use 'Clear' button before inputing information");
        addCourseButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addCourseButtonActionPerformed(evt);
            }
        });
        jPanel2.add(addCourseButton, java.awt.BorderLayout.CENTER);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Course Prerequisites");

        javax.swing.GroupLayout coursePanelLayout = new javax.swing.GroupLayout(coursePanel);
        coursePanel.setLayout(coursePanelLayout);
        coursePanelLayout.setHorizontalGroup(
            coursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, coursePanelLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(coursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, coursePanelLayout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(65, 65, 65))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, coursePanelLayout.createSequentialGroup()
                        .addComponent(courseTableLabel)
                        .addGap(149, 149, 149))))
            .addGroup(coursePanelLayout.createSequentialGroup()
                .addGroup(coursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(coursePanelLayout.createSequentialGroup()
                        .addGap(189, 189, 189)
                        .addComponent(courseEditLabel))
                    .addGroup(coursePanelLayout.createSequentialGroup()
                        .addGap(172, 172, 172)
                        .addGroup(coursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(coursePanelLayout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addComponent(courseSearchLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(courseSearchTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 136, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(clearAreaButton))
                    .addGroup(coursePanelLayout.createSequentialGroup()
                        .addGap(55, 55, 55)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 335, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(56, Short.MAX_VALUE))
        );
        coursePanelLayout.setVerticalGroup(
            coursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, coursePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(courseEditLabel)
                .addGap(29, 29, 29)
                .addGroup(coursePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(courseSearchTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(clearAreaButton)
                    .addComponent(courseSearchLabel))
                .addGap(48, 48, 48)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(courseTableLabel)
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        SeperatorPanel.setBackground(new java.awt.Color(153, 153, 153));

        seperator2Panel.setBackground(new java.awt.Color(102, 102, 102));
        seperator2Panel.setPreferredSize(new java.awt.Dimension(2, 0));

        javax.swing.GroupLayout seperator2PanelLayout = new javax.swing.GroupLayout(seperator2Panel);
        seperator2Panel.setLayout(seperator2PanelLayout);
        seperator2PanelLayout.setHorizontalGroup(
            seperator2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 2, Short.MAX_VALUE)
        );
        seperator2PanelLayout.setVerticalGroup(
            seperator2PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout SeperatorPanelLayout = new javax.swing.GroupLayout(SeperatorPanel);
        SeperatorPanel.setLayout(SeperatorPanelLayout);
        SeperatorPanelLayout.setHorizontalGroup(
            SeperatorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, SeperatorPanelLayout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addComponent(seperator2Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );
        SeperatorPanelLayout.setVerticalGroup(
            SeperatorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(seperator2Panel, javax.swing.GroupLayout.DEFAULT_SIZE, 457, Short.MAX_VALUE)
        );

        menuBar.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        fileMenu.setText("System");

        exitMenuItem.setText("Exit");
        exitMenuItem.setToolTipText("Exits the administrator terminal");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        helpMenu.setText("Help");

        helpMenuItem.setText("Help");
        helpMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                helpMenuItemActionPerformed(evt);
            }
        });
        helpMenu.add(helpMenuItem);

        menuBar.add(helpMenu);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(coursePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(SeperatorPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(degreePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(degreePanel, javax.swing.GroupLayout.DEFAULT_SIZE, 457, Short.MAX_VALUE)
            .addComponent(coursePanel, javax.swing.GroupLayout.DEFAULT_SIZE, 457, Short.MAX_VALUE)
            .addComponent(SeperatorPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void courseSearchTextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_courseSearchTextFieldFocusGained
        if(courseSearchTextField.getText().equals(HINT_TEXT)) {
            courseSearchTextField.setText("");
        }
    }//GEN-LAST:event_courseSearchTextFieldFocusGained

    private void courseSearchTextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_courseSearchTextFieldFocusLost
        if(courseSearchTextField.getText().equals("")) {
            courseSearchTextField.setText(HINT_TEXT);
        }
    }//GEN-LAST:event_courseSearchTextFieldFocusLost

    private void courseSearchTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_courseSearchTextFieldKeyPressed
        DefaultTableModel model = (DefaultTableModel) courseInfoTable.getModel();
        DefaultTableModel model2 = (DefaultTableModel) coursePrereqInfoTable.getModel();
        if(evt.getKeyCode() != 10) {
            return;
        }
        try {
            searchedCourse = catalog.findCourse(courseSearchTextField.getText().toUpperCase());
        } catch(CourseNotFoundException e) {
            JOptionPane.showMessageDialog(new JFrame(), "Course not found. Please try another search.", "Error", 2);
            return;
        }

        model.setValueAt(searchedCourse.getCourseCode(), 0, 0);
        model.setValueAt(searchedCourse.getSemesterOffered(), 0, 1);
        model.setValueAt(searchedCourse.getCourseCredit(), 0, 2);

        int row = 0;
        for(Course prereq : searchedCourse.getPrerequisites()) {
            // This will ensure there are 2 lines for users to add more prerequisites
            if(row >= 5) {
                model2.addRow(new String[1]);
            }
            model2.setValueAt(prereq.getCourseCode(), row, 0);
            row ++;
        }
        
        // Clean the rest of the table
        for(int i = model2.getRowCount()-1; i > row-1; i--) {
            // Make sure to leave the extra rows for addition
            if(i >= 7) {
                model2.removeRow(i);
            } else {
                model2.setValueAt(null, i, 0);
            }
        }
                
        addCourseButton.setVisible(false);
        updateCourseButton.setVisible(true);
    }//GEN-LAST:event_courseSearchTextFieldKeyPressed

    private void clearAreaButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearAreaButtonActionPerformed
        clearCourseInfo();
    }//GEN-LAST:event_clearAreaButtonActionPerformed

    private void degreeSearchTextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_degreeSearchTextFieldFocusGained
        if(degreeSearchTextField.getText().equals(HINT_TEXT2)) {
            degreeSearchTextField.setText("");
        }
    }//GEN-LAST:event_degreeSearchTextFieldFocusGained

    private void degreeSearchTextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_degreeSearchTextFieldFocusLost
        if(degreeSearchTextField.getText().equals("")) {
            degreeSearchTextField.setText(HINT_TEXT2);
        }
    }//GEN-LAST:event_degreeSearchTextFieldFocusLost

    //TODO
    private void degreeSearchTextFieldKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_degreeSearchTextFieldKeyPressed
        if(evt.getKeyCode() != 10) {
            return;
        }
        DefaultTableModel model = (DefaultTableModel) degreeInfoTable.getModel();
        
        String searchedDegree = degreeSearchTextField.getText().toUpperCase();
        int row = 0;
        
        for(String degree : degreeList) {
            if(degree.contains(searchedDegree)) {
                if(row >= 5) {
                    model.addRow(new String[2]);
                }
                model.setValueAt(degree.split(":")[0], row, 0);
                model.setValueAt(degree.split(":")[1], row, 1);
                row ++;
            }
        }
        
        // Clean the rest of the table
        for(int i = model.getRowCount()-1; i > row-1; i--) {
            // Make sure to leave the extra rows for addition
            if(i >= 5) {
                model.removeRow(i);
            } else {
                model.setValueAt(null, i, 0);
                model.setValueAt(null, i, 1);
            }
        }
        
    }//GEN-LAST:event_degreeSearchTextFieldKeyPressed

    private void clearDegreeTextButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearDegreeTextButtonActionPerformed
        degreeSearchTextField.setText(HINT_TEXT2);
        
        DefaultTableModel model = (DefaultTableModel) degreeInfoTable.getModel();
        // Clean the rest of the table
        for(int i = model.getRowCount()-1; i >= 0; i--) {
            // Make sure to leave the extra rows for addition
            if(i >= 5) {
                model.removeRow(i);
            } else {
                model.setValueAt(null, i, 0);
                model.setValueAt(null, i, 1);
            }
        }
    }//GEN-LAST:event_clearDegreeTextButtonActionPerformed

    private void helpMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_helpMenuItemActionPerformed
        JOptionPane.showMessageDialog(new JFrame(), 
                "This is the administrator database tool. "
                + "On the left, you will find course catalog information, and on the right, degree information\n\n"
                + "Information in a table can be updated by editing a cell.\n"
                + "You can search for pre-existing information to edit, or add your own, and save the information.\n\n"
                + "The information will of be saved if all columns filled in the row are filled.\n\n" 
                + "All courses added/removed/changed are automatically saved in the database. There is no need to \"save\"", "Help", 1);
    }//GEN-LAST:event_helpMenuItemActionPerformed

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        super.dispose();
    }//GEN-LAST:event_exitMenuItemActionPerformed

    private void addCourseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addCourseButtonActionPerformed
        if(searchedCourse != null) {
            JOptionPane.showMessageDialog(new JFrame(), "Please clear existing course information with the clear button.", "Error", 2);
            return;
        }
        
        if(courseInfoTable.getValueAt(0, 0) == null || courseInfoTable.getValueAt(0, 1) == null || courseInfoTable.getValueAt(0, 2) == null) {
            return;
        }
        
        DefaultTableModel entryModel = (DefaultTableModel) courseInfoTable.getModel();
        searchedCourse = new Course();
        searchedCourse.setCourseCode(entryModel.getValueAt(0, 0).toString().toUpperCase());
        searchedCourse.setSemesterOffered(entryModel.getValueAt(0, 1).toString().toUpperCase());
        try {
            searchedCourse.setCourseCredit(Double.parseDouble(entryModel.getValueAt(0, 2).toString()));
        } catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(new JFrame(), "Invalid credit value.", "Error", 2);
        }

        DefaultTableModel model = (DefaultTableModel) coursePrereqInfoTable.getModel();
        ArrayList<Course> prereqs = new ArrayList<>();
        for(int i = 0; i < model.getRowCount()-1; i++) {
            if(model.getValueAt(i, 0) != null) {
                prereqs.add(new Course());
                prereqs.get(i).setCourseCode(model.getValueAt(i, 0).toString().toUpperCase());
            }
        }
        searchedCourse.setPrerequisites(prereqs);
        
        String title = JOptionPane.showInputDialog(new JFrame(), "If you would like to set the course title, enter it below. If you do not wish to, press cancel.", "Change Title", -1);
        if(title != null) {
            searchedCourse.setCourseTitle(title);
        }

        try {
            catalog.addCourse(searchedCourse);
        } catch(CourseAlreadyExistsException e) {
            JOptionPane.showMessageDialog(new JFrame(), "Unable to add course. It already exits.", "Error", 2);
            return;
        }
        updateCourseButton.setVisible(true);
        addCourseButton.setVisible(false);
    }//GEN-LAST:event_addCourseButtonActionPerformed

    private void updateCourseButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateCourseButtonActionPerformed
        if(searchedCourse == null) {
            JOptionPane.showMessageDialog(new JFrame(), "Please search for a valid course.", "Error", 2); // This should never need to appear
            return;
        }
        
        Course originalCourse = new Course(searchedCourse);
        if(courseInfoTable.getValueAt(0, 0) == null || courseInfoTable.getValueAt(0, 1) == null || courseInfoTable.getValueAt(0, 2) == null) {
            return;
        }
        
        // Design limitation would make ensuring that the correct course is being updated tough
//        searchedCourse.setCourseCode(courseInfoTable.getValueAt(0, 0).toString());
        searchedCourse.setSemesterOffered(courseInfoTable.getValueAt(0, 1).toString().toUpperCase());
        
        DefaultTableModel model = (DefaultTableModel) coursePrereqInfoTable.getModel();
        ArrayList<Course> prereqs = new ArrayList<>();
        for(int i = 0; i < model.getRowCount()-1; i++) {
            if(model.getValueAt(i, 0) != null) {
                prereqs.add(new Course());
                prereqs.get(i).setCourseCode(model.getValueAt(i, 0).toString().toUpperCase());
            }
        }
        searchedCourse.setPrerequisites(prereqs);
        
        try {
            searchedCourse.setCourseCredit(Double.parseDouble(courseInfoTable.getValueAt(0, 2).toString()));
        } catch(NumberFormatException e) {
            JOptionPane.showMessageDialog(new JFrame(), "Invalid credit value.", "Error", 2);
            return;
        }

        String title = JOptionPane.showInputDialog(new JFrame(), "If you would like to change the course title, enter it below. If you do not wish to, press cancel.", "Change Title", -1);
        if(title != null) {
            searchedCourse.setCourseTitle(title);
        }

        try {
            catalog.updateCourse(searchedCourse, originalCourse);
        } catch(CourseNotFoundException e) {
            JOptionPane.showMessageDialog(new JFrame(), "Course does not exist. Unable to update.", "Error", 2); // This should never appear
        }
    }//GEN-LAST:event_updateCourseButtonActionPerformed

    private void addDegreeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addDegreeButtonActionPerformed
        DefaultTableModel model = (DefaultTableModel) degreeInfoTable.getModel();
        
        for(int i = 0; i < model.getRowCount()-1; i++) {
            String degree = model.getValueAt(i, 0).toString() + ":" + model.getValueAt(i, 1).toString();
            if(!degreeList.contains(degree)) {
                degreeList.add(degree);
            }
        }
    }//GEN-LAST:event_addDegreeButtonActionPerformed

    private void updateDegreeButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateDegreeButtonActionPerformed
        DefaultTableModel model = (DefaultTableModel) degreeInfoTable.getModel();
        
        for(int i = 0; i < model.getRowCount()-1; i++) {
            if(model.getValueAt(i, 0) != null) {
                String degree = model.getValueAt(i, 0).toString() + ":" + model.getValueAt(i, 1).toString();
                if(!degreeList.get(i).equals(degree)) {
                    degreeList.remove(i);
                    degreeList.add(degree);
                }
            }
        }
    }//GEN-LAST:event_updateDegreeButtonActionPerformed

    private void clearCourseInfo() {
        courseSearchTextField.setText(HINT_TEXT);
        searchedCourse = null;
        updateCourseButton.setVisible(false);
        addCourseButton.setVisible(true);
        
        DefaultTableModel model = (DefaultTableModel) courseInfoTable.getModel();
        DefaultTableModel model2 = (DefaultTableModel) coursePrereqInfoTable.getModel(); 
        
        model.setValueAt(null, 0, 0);
        model.setValueAt(null, 0, 1);
        model.setValueAt(null, 0, 2);
        
        for(int i = model2.getRowCount()-1; i >= 0; i--) {
            if(i >= 7) {
                model2.removeRow(i);
            } else {
                model2.setValueAt(null, i, 0);
            }
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Administrator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Administrator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Administrator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Administrator.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Administrator().setVisible(true);
            }
        });
    }

    @Override
    public String toString() {
        return "This is a GUI for Administrator";
    }
    
    @Override
    public boolean equals(Object o) {
        if(o == null) {
            //System.out.println("The tested object is null");
            return false;
        } else if(o instanceof Administrator){
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        return hash;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel SeperatorPanel;
    private javax.swing.JButton addCourseButton;
    private javax.swing.JButton addDegreeButton;
    private javax.swing.JButton clearAreaButton;
    private javax.swing.JButton clearDegreeTextButton;
    private javax.swing.JLabel courseEditLabel;
    private javax.swing.JTable courseInfoTable;
    private javax.swing.JPanel coursePanel;
    private javax.swing.JTable coursePrereqInfoTable;
    private javax.swing.JLabel courseSearchLabel;
    private javax.swing.JTextField courseSearchTextField;
    private javax.swing.JLabel courseTableLabel;
    private javax.swing.JPanel degreeChangePanel;
    private javax.swing.JLabel degreeEditLabel;
    private javax.swing.JTable degreeInfoTable;
    private javax.swing.JPanel degreePanel;
    private javax.swing.JLabel degreeSearchLabel;
    private javax.swing.JTextField degreeSearchTextField;
    private javax.swing.JLabel degreeTableLabel;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JMenuItem helpMenuItem;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JPanel seperator2Panel;
    private javax.swing.JButton updateCourseButton;
    private javax.swing.JButton updateDegreeButton;
    // End of variables declaration//GEN-END:variables
}
