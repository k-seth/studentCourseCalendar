/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package univ;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Seth
 */
public class DegreeRequiredCourses {
    /**
     * A helper function that sets all required courses for a BCG.
     * 
     * @param catalog
     * @return
     */
    public static Degree setBCGRequiredCourses(CourseCatalog catalog) {
        BufferedReader fileReader = null;
        String temp;
        String[] tempString;;
        BCG bcgObject = new BCG();
        
        try {    
            try {
                fileReader = new BufferedReader(new FileReader("BCG.txt"));
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TestClass.class.getName()).log(Level.SEVERE, null, ex);
            }
            ArrayList<String> requiredCourses = new ArrayList<>();
            
            /* When reading from the file, trim any excess whitespace to account for newlines */
            while(((temp = fileReader.readLine())) != null) {
                tempString = temp.trim().split(",");
                for(int i = 1; i < tempString.length; i++) {
                    requiredCourses.add(tempString[i]);
                }
                
                bcgObject = new BCG();
                bcgObject.updateCourseCatalog(catalog);
                bcgObject.setRequiredCourses(requiredCourses);
            }
            fileReader.close();
            return bcgObject;
        } catch (IOException ex) {
            Logger.getLogger(TestClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    /**
     * A helper function that sets all required courses for a CS.
     * 
     * @param catalog
     * @return
     */
    public static Degree setCSRequiredCourses(CourseCatalog catalog) {
        BufferedReader fileReader = null;
        String temp;
        String[] tempString;
        CS csObject = new CS();
        
        try {    
            try {
                fileReader = new BufferedReader(new FileReader("CS.txt"));
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TestClass.class.getName()).log(Level.SEVERE, null, ex);
            }
            ArrayList<String> requiredCourses = new ArrayList<>();
            
            /* When reading from the file, trim any excess whitespace to account for newlines */
            while(((temp = fileReader.readLine())) != null) {
                tempString = temp.trim().split(",");
                for(int i = 1; i < tempString.length; i++) {
                    requiredCourses.add(tempString[i]);
                }
                
                /* Create the objects and pass in the course catalog and set required courses */
                csObject = new CS();
                csObject.updateCourseCatalog(catalog);
                csObject.setRequiredCourses(requiredCourses);
            }
            fileReader.close();
            return csObject;
            
        } catch (IOException ex) {
            Logger.getLogger(TestClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    /**
     * A helper function that sets all required courses for a SENG.
     * 
     * @param catalog
     * @return
     */
    public static Degree setSENGRequiredCourses(CourseCatalog catalog) {
        BufferedReader fileReader = null;
        String temp;
        String[] tempString;
        
        SEng sengObject = new SEng();
        
        try {    
            try {
                fileReader = new BufferedReader(new FileReader("SENG.txt"));
            } catch (FileNotFoundException ex) {
                Logger.getLogger(TestClass.class.getName()).log(Level.SEVERE, null, ex);
            }
            ArrayList<String> requiredCourses = new ArrayList<>();
            
            /* When reading from the file, trim any excess whitespace to account for newlines */
            while(((temp = fileReader.readLine())) != null) {
                tempString = temp.trim().split(",");
                for(int i = 1; i < tempString.length; i++) {
                    requiredCourses.add(tempString[i]);
                }
                
                /* Create the objects and pass in the course catalog and set required courses */
                sengObject = new SEng();
                sengObject.updateCourseCatalog(catalog);
                sengObject.setRequiredCourses(requiredCourses);
            }
            fileReader.close();
            return sengObject;
        } catch (IOException ex) {
            Logger.getLogger(TestClass.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @Override
    public String toString() {
        return "DegreeRequiredCourses";
    }
    
}
