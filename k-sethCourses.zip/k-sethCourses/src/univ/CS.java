package univ;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 1
 */

/**
 * A concrete extension of HonoursDegree.
 * Allows for objects of a Degree to be created.
 */
public class CS extends HonoursDegree {

    private static final long serialVersionUID = 1L;
    private static final String MAJOR = "CS";
    
    /**
     * An empty, parameterless constructor.
     */
    public CS() {
    }
    
    @Override
    public String toString() {
        return "BCH:CS";
    }
    
    @Override
    public boolean equals(Object o) {
        if(o == null) {
            //System.out.println("The tested object is null");
            return false;
        } else if(o instanceof CS){
            //System.out.println("The tested object is an instance of CS");
            return true;
        } else {
            //System.out.println("The tested object is not a CS");
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 3;
        return hash;
    }
}
