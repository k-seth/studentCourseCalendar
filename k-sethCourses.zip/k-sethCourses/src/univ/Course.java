package univ;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Objects;

/**
 * The Course class allows for the creation and manipulation of a singular course.
 * Implements Serializable to allow Course objects to be written to file.
 */
public class Course implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String courseCode;
    private String courseTitle;
    private String courseSemester;
    private double courseCredit;
    private ArrayList<Course> preReqList = new ArrayList<>();
    
    /**
     * An empty, parameterless constructor for Serialization.
     */
    public Course() {
    }
    
    /**
     * A constructor that allows for the creation of Course with basic information.
     * No information related to course enrollment is handled and should be set separately.
     * 
     * @param courseCode
     * @param courseCredit
     * @param courseTitle
     * @param courseSemester
     * @param list
     */
    public Course(String courseCode, double courseCredit, String courseTitle, String courseSemester, ArrayList<Course> list) {
        this.courseCode = courseCode;
        this.courseCredit = courseCredit;
        this.courseTitle = courseTitle;
        this.courseSemester = courseSemester;
        if(list != null) {
            preReqList = new ArrayList<>(list);
        }   
    }
    
    /**
     * A copy constructor that takes in a course and does a deep copy.
     * For generic course information, a call to another Course constructor is made.
     * 
     * @param course
     */
    public Course(Course course) {
        /* Rather than duplicate a large block of code, simply make a call to the other constructor, and then copy the last few members */
        this(course.getCourseCode(), course.getCourseCredit(), course.getCourseTitle(), course.getSemesterOffered(), course.getPrerequisites());
    }
    
    /**
     * Sets the course code equal to the passed argument.
     * 
     * @param courseCode
     */
    protected void setCourseCode(String courseCode) {
        this.courseCode = courseCode;
    }
    
    /**
     * Returns a String representing the course code.
     * 
     * @return
     */
    public String getCourseCode() {
        return courseCode;
    }
    
    /**
     * Sets the title of the course equal to the passed argument.
     * 
     * @param courseTitle
     */
    protected void setCourseTitle(String courseTitle) {
        this.courseTitle = courseTitle;
    }
    
    /**
     * Returns a String representing the title of the course.
     * 
     * @return
     */
    public String getCourseTitle() {
        return courseTitle;
    }
    
    /**
     * Sets the credit value of the course equal to the passed argument.
     * 
     * @param credit
     */
    protected void setCourseCredit(double credit) {
        courseCredit = credit;
    }
    
    /**
     * Returns a double value representing the credit value of the course.
     * 
     * @return
     */
    public double getCourseCredit() {
        return courseCredit;
    }
    
    /**
     * Sets the prerequisites for the course equal to the passed argument.
     * If an empty list is passed then it is ignored.
     * 
     * @param preReqList
     */
    protected void setPrerequisites(ArrayList<Course> preReqList) {
        if(preReqList != null) {
            this.preReqList = new ArrayList<>(preReqList);
        }
    }
    
    /**
     * Returns an ArrayList of Courses, representing the prerequisite courses for the course.
     * An anonymous ArrayList is returned to prevent data modification.
     * 
     * @return
     */
    public ArrayList<Course> getPrerequisites() {
        return new ArrayList<>(preReqList);
    }
    
    /**
     * Sets the semester offered equal to the passed argument.
     * 
     * @param semester
     */
    protected void setSemesterOffered(String semester) {
        courseSemester = semester;
    }
    
    /**
     * Returns a String representing the semester the course is offered.
     * 
     * @return
     */
    public String getSemesterOffered() {
        return courseSemester;
    }
    
    
    @Override
    public String toString() {
        return courseCode;
    }
    
    @Override
    public boolean equals(Object o) {
        if(o == null) {
//            System.out.println("The tested object is null");
            return false;
        } else if(o instanceof Course){
//            System.out.println("The tested object is an instance of Course");
            return true;
        } else {
//            System.out.println("The tested object is not a Course");
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + Objects.hashCode(this.courseCode);
        hash = 79 * hash + Objects.hashCode(this.courseTitle);
        hash = 79 * hash + Objects.hashCode(this.courseSemester);
        hash = 79 * hash + (int) (Double.doubleToLongBits(this.courseCredit) ^ (Double.doubleToLongBits(this.courseCredit) >>> 32));
        hash = 79 * hash + Objects.hashCode(this.preReqList);
        return hash;
    }
}
