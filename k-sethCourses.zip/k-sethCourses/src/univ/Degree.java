package univ;

/**
 *
 * @author Seth
 * Project: CIS*2430 Assignment 2
 */

import exceptions.CourseNotFoundException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * An abstract class that establishes the root for the degree tree.
 * Defines some abstract methods, and defines some.
 * Implements Serializable to allow all subclasses of Degree to be written to file.
 */
abstract public class Degree implements Serializable{

    private static final long serialVersionUID = 1L;
    private final ArrayList<Course> requiredCourses;
    
    private CourseCatalog allCourses;
    private String degTitle;

    /**
     * Constructor creates a new ArrayList. 
     * Used by subclasses during serialization.
     */
    public Degree() {
        requiredCourses = new ArrayList<>();
    }
    
    /**
     * Helper function to keep the degree up-to-date on the course catalog.
     * 
     * @param catalog
     */
    protected void updateCourseCatalog(CourseCatalog catalog) {
        allCourses = catalog;
    }
    
    /**
     * Returns a string that represents the Degree title.
     * <p>
     * Declared as abstract in the root class. Subclasses must will need to override and implement.
     * 
     * @return 
     */
    public String getDegreeTitle() {
        return degTitle;
    }
    
    /**
     * Sets the Degree title to the String supplied by the argument.
     * <p>
     * Declared as abstract in the root class. Subclasses must will need to override and implement.
     * 
     * @param title
     */
    protected void setDegreeTitle(String title) {
        degTitle = title;
    }
    
    /**
     * Sets the required courses for a degree, and stores them in the member ArrayList.
     * A course will only be added if it exists in the CourseCatalog. Otherwise, it will be ignored.
     * 
     * @param listOfRequiredCourseCodes 
     */
    protected void setRequiredCourses(ArrayList<String> listOfRequiredCourseCodes) {
        /* Since this code can be implemented by all 3 majors, it can be placed here */
        /* Loop over the array list holding the course codes, and then look up the course in the catalog and at the course in the catalog to the new arraylist of courses */
        for (int i = 0; i < listOfRequiredCourseCodes.size(); i++) {
            try {
                if(allCourses.findCourse(listOfRequiredCourseCodes.get(i)) != null) {
                    requiredCourses.add(allCourses.findCourse(listOfRequiredCourseCodes.get(i)));
                }
            } catch (CourseNotFoundException ex) {
            }
        }
    }
    
    /**
     * Returns an ArrayList of all required courses for a degree/major.
     * An anonymous ArrayList is returned to ensure data is not modified unexpectedly.
     * 
     * @return 
     */
    public ArrayList<Course> getRequiredCourses() {
        return new ArrayList<>(requiredCourses);
    }
    
    /**
     * Returns a boolean representing if the user has met the requirements to graduate.
     * <p>
     * Declared as abstract in the root class. Subclasses must will need to override and implement.
     * 
     * @param allTheCoursesPlannedAndTaken
     * @return 
     */
    public abstract boolean meetsRequirements(ArrayList<Course> allTheCoursesPlannedAndTaken);
    
    /**
     * Returns a double representing the number of credits that are still in need of completion based on the courses in the plan of study.
     * <p>
     * Declared as abstract in the root class. Subclasses must will need to override and implement.
     * 
     * @param allTheCoursesPlannedAndTaken
     * @return 
     */
    abstract double numberOfCreditsRemaining(ArrayList<Course> allTheCoursesPlannedAndTaken);
    
    /**
     * Returns an ArrayList representing which required courses are not present in plan of study.
     * 
     * @param allTheCoursesPlannedAndTaken
     * @return 
     */
    public ArrayList<Course> remainingRequiredCourses(ArrayList<Course> allTheCoursesPlannedAndTaken) {
        HashMap<String, Course> allTheCourses = new HashMap<>();
        HashMap<String, Course> missing = new HashMap<>();
        ArrayList<Course> returnList = new ArrayList<>();
        
        for (Course listCourse : allTheCoursesPlannedAndTaken) {
            allTheCourses.put(listCourse.getCourseCode(), listCourse);
        }
        
        /* To stream line later accessing of the required courses, just put the ArrayList in a HashMap (Order 1 vs Order n) */
        for (Course course : requiredCourses) {
            if(!allTheCourses.containsKey(course.getCourseCode())) {
                missing.put(course.getCourseCode(), course);
            }
        }
        
        /* Place the course objects in the HashMap back in to an ArrayList and return it since that is the required format *Grumble grumble* */
        for (Course course : missing.values()) {
            returnList.add(course);
        }
        
        return returnList;
    }
    
    @Override
    public String toString() {
        return "An abstract class representing a Degree";
    }
    
    @Override
    public boolean equals(Object o) {
        if(o == null) {
            return false;
        } else if(o instanceof Degree){
            return true;
        } else {
            return false;
        }
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 89 * hash + Objects.hashCode(this.requiredCourses);
        hash = 89 * hash + Objects.hashCode(this.allCourses);
        hash = 89 * hash + Objects.hashCode(this.degTitle);
        return hash;
    }
}
