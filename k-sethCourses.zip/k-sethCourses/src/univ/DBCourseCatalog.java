/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package univ;

import exceptions.CourseAlreadyExistsException;
import exceptions.CourseNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Objects;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 *
 * @author Seth
 */
public class DBCourseCatalog extends CourseCatalog {
    
    private static final long serialVersionUID = 1L;
    
    private final MyConnection dbConnect;
    private final HashMap<String, Course> courseCatalog = new HashMap<>();

    /**
     * A constructor for a new course catalog loaded in from the database
     */
    public DBCourseCatalog() {
        dbConnect = new MyConnection(DBDetails.username, DBDetails.password);
        loadAllCourses();
    }
    
    @Override
    public Course findCourse(String courseCode) throws CourseNotFoundException {
        if(!courseCatalog.containsKey(courseCode)) {
            throw new CourseNotFoundException();
        }
        return courseCatalog.get(courseCode);
    }

    @Override
    protected void removeCourse(Course toRemove) {
        if(courseCatalog.containsKey(toRemove.getCourseCode())) {
            courseCatalog.remove(toRemove.getCourseCode());
        }
        dbConnect.deleteCourse(toRemove.getCourseCode());
    }

    @Override
    protected void updateCourse(Course newInfo, Course original) throws CourseNotFoundException {
        if(courseCatalog.containsKey(original.getCourseCode())) {
            courseCatalog.replace(original.getCourseCode(), original, newInfo);
        } else {
            throw new CourseNotFoundException();
        }
        // Map all the courses in the list to a string (based on course code), and then join them together using a colon as a delimiter
        String prereqs = newInfo.getPrerequisites().stream()
                .map(c -> c.getCourseCode())
                .collect(Collectors.joining(":"));
        
        dbConnect.deleteCourse(original.getCourseCode());
        dbConnect.addCourse(newInfo.getCourseCode(), Double.toString(newInfo.getCourseCredit()), newInfo.getCourseTitle(), newInfo.getSemesterOffered(), prereqs);
    }

    @Override
    protected void addCourse(Course toAdd) throws CourseAlreadyExistsException {
        if(courseCatalog.containsKey(toAdd.getCourseCode())) {
            throw new CourseAlreadyExistsException();
            // There is a case where the course could be not well formed, but it is not being considered here
        }
        String prereqs = toAdd.getPrerequisites().stream()
                .map(c -> c.getCourseCode())
                .collect(Collectors.joining(":"));
        
        dbConnect.addCourse(toAdd.getCourseCode(), Double.toString(toAdd.getCourseCredit()), toAdd.getCourseTitle(), toAdd.getSemesterOffered(), prereqs);
        courseCatalog.put(toAdd.getCourseCode(), toAdd);
    }
    
    /**
     * Loads all course entries into a list from the database.
     */
    private void loadAllCourses() {
        ArrayList<String> allRecords = dbConnect.getAllCourses();
        for(String record : allRecords) {
            try {
                parseRecord(record);
            } catch (CourseNotFoundException ex) {
                Logger.getLogger(DBCourseCatalog.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
    
    /**
     * Parses a record and constructs a course based on the information.
     * 
     * @param record
     * @throws exception.CourseNotFoundException
     */
    private void parseRecord(String record) throws CourseNotFoundException {
        ArrayList<Course> reqCourses;
        String[] splitString;
        String[] req;

        Course tempCourse;
        if(record == null) {
            throw new CourseNotFoundException();
        }
        
        /* Only override what exists if a file can be found */
        splitString = record.trim().split(",");
        if(splitString[0].length() == 0 || splitString[1].length() == 0 || splitString[2].length() == 0 || splitString[3].length() == 0) {
            throw new CourseNotFoundException();
        }

        reqCourses = new ArrayList<>();
        if(splitString.length > 4) {
            req = splitString[4].split(":");

            /* Add any prerequisite courses first */
            for(int i = 0; i < req.length; i++) {
                /* If a course does not exist in the catalog, make sure to create a new course with just a course code */
                if(!courseCatalog.containsKey(req[i])) {
                    tempCourse = new Course();
                    tempCourse.setCourseCode(req[i]);
                    courseCatalog.put(req[i], tempCourse);
                }
                reqCourses.add(courseCatalog.get(req[i]));
            }
        }
        
        /* This is for adding the course */
        /* Check if the course already exists (This means it will have been added as prerequisite course)*/
        /* If the course already exists, make sure it is not already filled in. If it is, ignore the new entry and move on */
        if(courseCatalog.containsKey(splitString[0]) && !splitString[2].equals(courseCatalog.get(splitString[0]).getCourseTitle())) {
            courseCatalog.get(splitString[0]).setCourseCredit(Double.parseDouble(splitString[1]));
            courseCatalog.get(splitString[0]).setCourseTitle(splitString[2]);
            courseCatalog.get(splitString[0]).setSemesterOffered(splitString[3]);
            courseCatalog.get(splitString[0]).setPrerequisites(reqCourses);
        } else if(!courseCatalog.containsKey(splitString[0])) {
            courseCatalog.put(splitString[0], new Course(splitString[0], Double.parseDouble(splitString[1]), splitString[2], splitString[3], reqCourses));
        }
    }

    @Override
    public String toString() {
        return "DBCourseCatalog{" + "dbConnect=" + dbConnect + ", courseCatalog=" + courseCatalog + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 67 * hash + Objects.hashCode(this.dbConnect);
        hash = 67 * hash + Objects.hashCode(this.courseCatalog);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final DBCourseCatalog other = (DBCourseCatalog) obj;
        if (!Objects.equals(this.dbConnect, other.dbConnect)) {
            return false;
        }
        if (!Objects.equals(this.courseCatalog, other.courseCatalog)) {
            return false;
        }
        return true;
    }
    
    
}
